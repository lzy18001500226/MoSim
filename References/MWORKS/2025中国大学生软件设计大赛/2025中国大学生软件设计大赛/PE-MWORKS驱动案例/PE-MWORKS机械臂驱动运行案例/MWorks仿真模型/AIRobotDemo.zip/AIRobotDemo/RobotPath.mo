﻿type RobotPath = enumeration(
  Path1 "路径1，标准路线", 
  Path2 "路径2，下方路径", 
  Path3 "路径3，反向路线") 
  "用户互动路径选项";