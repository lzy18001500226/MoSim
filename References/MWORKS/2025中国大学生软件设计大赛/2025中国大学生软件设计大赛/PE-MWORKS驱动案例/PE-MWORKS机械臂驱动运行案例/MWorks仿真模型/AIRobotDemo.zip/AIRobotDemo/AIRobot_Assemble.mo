﻿model AIRobot_Assemble "协同机器人"

 annotation(uses(TYMultibody,TYMechanics));

  annotation(__MWORKS(version = "2025a", ContinueSimConfig(SaveContinueFile = "false", SaveBeforeStop = "false", NumberBeforeStop = 1, FixedContinueInterval = "false", ContinueIntervalLength = 0.929, ContinueTimeVector)), Diagram(coordinateSystem(extent = {{-100, -100}, {100, 100}}, 
    grid = {2, 2})), experiment(Algorithm = Dassl, InlineIntegrator = false, InlineStepSize = false, Interval = 0.001, StartTime = 0, StopTime = 13, Tolerance = 0.0001));
  TYMultibody.Joints.Fixed fixed(r(displayUnit = "mm") = ((({-2681.234, 168.211, -203.176}))) / (1000)) 
    annotation(Placement(transformation(origin = {-80, -20}, extent = {{-10, -10}, {10, 10}})));
  TYMultibody.Joints.Fixed fixed1 
    annotation(Placement(transformation(origin = {-34, -20}, 
    extent = {{-10, -10}, {10, 10}})));
  TYMultibody.Joints.Fixed fixed2(r = {2, 0, 0}) 
    annotation(Placement(transformation(origin = {26, -20}, 
    extent = {{-10, -10}, {10, 10}})));
  inner TYMultibody.World world 
    annotation(Placement(transformation(origin = {-62, 82}, 
    extent = {{-10, -10}, {10, 10}})));
  Robot_Single robot_Single(path=RobotPath.Path2) 
    annotation(Placement(transformation(origin = {-68, 6}, 
    extent = {{-10, -10}, {10, 10}})));
  Robot_Single robot_Single1(path=RobotPath.Path2) 
    annotation(Placement(transformation(origin = {-8, 6}, 
    extent = {{-10, -10}, {10, 10}})));
  DeviceDrivers.Blocks.Componment.PeComponment.PETypeEncodeAndSend_RobotAsse pETypeEncodeAndSend_RobotAsse(remoteAddress="127.0.0.1", localAddress = "127.0.0.1") 
    annotation(Placement(transformation(origin = {-16, 82}, 
    extent = {{-10, -10}, {10, 10}})));
  Robot_Single robot_Single2(path=RobotPath.Path3) 
    annotation(Placement(transformation(origin = {52, 6}, 
    extent = {{-10, -10}, {10, 10}})));
equation

  //robot1
  pETypeEncodeAndSend_RobotAsse.dataBus.R1_angle1 = robot_Single.revolute.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R1_angle2 = robot_Single.revolute1.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R1_angle3 = robot_Single.revolute2.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R1_angle4 = robot_Single.revolute3.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R1_angle5 = robot_Single.revolute4.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R1_angle6 = robot_Single.revolute5.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R1_x1 = robot_Single.prismatic.s_rel;
  pETypeEncodeAndSend_RobotAsse.dataBus.R1_x2 = robot_Single.prismatic1.s_rel;

  //robot2
  pETypeEncodeAndSend_RobotAsse.dataBus.R2_angle1 = robot_Single1.revolute.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R2_angle2 = robot_Single1.revolute1.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R2_angle3 = robot_Single1.revolute2.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R2_angle4 = robot_Single1.revolute3.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R2_angle5 = robot_Single1.revolute4.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R2_angle6 = robot_Single1.revolute5.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R2_x1 = robot_Single1.prismatic.s_rel;
  pETypeEncodeAndSend_RobotAsse.dataBus.R2_x2 = robot_Single1.prismatic1.s_rel;

  //robot3
  pETypeEncodeAndSend_RobotAsse.dataBus.R3_angle1 = robot_Single2.revolute.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R3_angle2 = robot_Single2.revolute1.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R3_angle3 = robot_Single2.revolute2.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R3_angle4 = robot_Single2.revolute3.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R3_angle5 = robot_Single2.revolute4.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R3_angle6 = robot_Single2.revolute5.phi_rel * 57.3;
  pETypeEncodeAndSend_RobotAsse.dataBus.R3_x1 = robot_Single2.prismatic.s_rel;
  pETypeEncodeAndSend_RobotAsse.dataBus.R3_x2 = robot_Single2.prismatic1.s_rel;



  connect(robot_Single.frame_a, fixed.frame_b) 
    annotation(Line(origin = {-69, -12}, 
    points = {{1, 8}, {1, -8}, {-1, -8}}, 
    color = {95, 95, 95}, 
    thickness = 0.5));
  connect(robot_Single1.frame_a, fixed1.frame_b) 
    annotation(Line(origin = {-13, -12}, 
    points = {{5, 8}, {5, -8}, {-11, -8}}, 
    color = {95, 95, 95}, 
    thickness = 0.5));
  connect(robot_Single2.frame_a, fixed2.frame_b) 
    annotation(Line(origin = {44, -12}, 
    points = {{8, 8}, {8, -8}, {-8, -8}}, 
    color = {95, 95, 95}, 
    thickness = 0.5));

end AIRobot_Assemble;