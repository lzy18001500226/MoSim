# This is a sample Python script.

# Press Alt+Shift+X to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import time

from usvlib4ros.usvRosUtil import LogUtil,USVRosbridgeClient,RosSrvClientProxy,RosTopicProxy
from usvlib4ros.msg import GlobalData
from usvlib4ros.navigation import USVAutoNavigationService


class USVNavMain:

    @classmethod
    def start(cls,host,port):
        USVRosbridgeClient.initRoslibpyLogger()
        GlobalData.Instance = GlobalData().getInstance()

        RosSrvClientProxy.Host = host
        RosSrvClientProxy.Port = port

        RosTopicProxy.Host = host
        RosTopicProxy.Port = port

        RosTopicProxy.startService()
        USVAutoNavigationService.startService()
        pass
    pass

# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    USVNavMain.start("192.168.0.110",9090)
    # USVNavMain.start("192.168.1.126", 9090)
    while True:
        time.sleep(1)



# See PyCharm help at https://www.jetbrains.com/help/pycharm/
