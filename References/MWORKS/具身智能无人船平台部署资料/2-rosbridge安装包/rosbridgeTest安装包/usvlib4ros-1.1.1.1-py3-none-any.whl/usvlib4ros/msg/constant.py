

class Constants:
    """usv constant"""
    Failed = 0
    Success = 1

    class WorkMode:
        AutoReturn = -1
        Ready = 0
        Mannual = 1
        Auto = 2
        pass

    class PoseMode:
        UintyPose = 2
        gpsPose = 1