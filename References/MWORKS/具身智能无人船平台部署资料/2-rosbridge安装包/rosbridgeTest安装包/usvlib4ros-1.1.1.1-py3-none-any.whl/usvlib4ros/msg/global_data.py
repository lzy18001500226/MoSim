
import threading

from .pose import Pose
from .vehicle_command import VehicleCommand
from .route import Point,Route,RouteMeta
from .auto_command import AutoCommand
from .gps_info import GPSInfo

class GlobalData:

    Instance = None

    @classmethod
    def getInstance(cls):
        if cls.Instance is None:
            cls.Instance = GlobalData()

        return cls.Instance

    def __init__(self):
        """"""

        """input"""
        self.pose = Pose()
        self.gpsInfo = GPSInfo()
        self.autoCommand = AutoCommand()

        self.__routeUpdateTime = 0.0 #second ,
        self.__route = Route()

        """output"""
        self.autoNavigationOutput = VehicleCommand()
        self.routeMeta = RouteMeta()
        """local tmp"""
        self.parameterAdjustMap = {}
        self.parameterMonitorMap = {}
        self.routeLock = threading.Lock()
        pass

    def getRouteInfo(self):
        try:
            self.routeLock.acquire()
            return self.__routeUpdateTime,self.__route
        finally:
            self.routeLock.release()

    def updateRouteInfo(self,route,routeUpdateTime):
        try:
            self.routeLock.acquire()
            self.__route = route
            self.__routeUpdateTime = routeUpdateTime
        finally:
            self.routeLock.release()

    pass