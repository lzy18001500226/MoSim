#!/usr/bin/env python
#coding:utf-8


import serial
import serial.tools.list_ports
import time
import numpy as np
import threading

from usvlib4ros.usvRosUtil import LogUtil
from usvlib4ros.msg import IMUInfo
from usvlib4ros.msg import GlobalData

#加速度：0x55 0x51 AxL AxH AyL AyH AzL AzH TL TH SUM
#角速度：0x55 0x52 wxL wxH wyL wyH wzL wzH TL TH SUM
#角度：  0x55 0x53 RollL RollH PitchL PitchH YawL YawH TL TH SUM


class IMUService:

    Instance = None

    def __init__(self,port,baud):
        self.imuInfo = GlobalData.getInstance().imuInfo
        self.port = port
        self.baud = 115200

    @classmethod
    def startService(cls,port,baud):
        Instance = IMUService(port,baud)
        thread_rcv = threading.Thread(target=Instance.serial_readers)
        thread_rcv.setDaemon(True)
        thread_rcv.start()
        pass

    def extract_raw_data(self, data,imuInfo):
        # 根据报文格式读取角速度数据
        # 0x55 0x52 + data + CRC(8bits)
        length = 9
        ext_omega = None
        ext_angle = None
        try:
            st = data.index(b'\x55')  # 寻找报文引导字
            if st >= 0:
                reserved = data[st + 1]  # 数据类型
                if reserved == 82:  # 0x52，提取角速度消息
                    if st + length + 1 < len(data):
                        if imuInfo.count_omega == 0:
                            imuInfo.time_now = imuInfo.time_last = time.time()
                        else:
                            imuInfo.time_last = imuInfo.time_now
                            imuInfo.time_now = time.time()

                        ext_omega = data[st:st + length + 2]
                        temp = int.from_bytes(ext_omega[6:8], byteorder='little', signed=True)
                        imuInfo.omega = temp / 32768 * 2000
                        imuInfo.record_omega.append(imuInfo.omega)  # deg/s
                        data = data[st + length + 2:]
                        imuInfo.count_omega += 1

                        imuInfo.omega_inte += imuInfo.omega * (imuInfo.time_now - imuInfo.time_last)
                        imuInfo.omega_inte = (imuInfo.omega_inte + 180) % 360 - 180
                        imuInfo.record_inte.append(imuInfo.omega_inte)

                elif reserved == 83:  # 0x53，提取角度消息
                    if st + length + 1 < len(data):
                        ext_angle = data[st:st + length + 2]
                        temp3 = int.from_bytes(ext_angle[6:8], byteorder='little', signed=True)
                        temp2 = int.from_bytes(ext_angle[4:6], byteorder='little', signed=True)
                        temp1 = int.from_bytes(ext_angle[2:4], byteorder='little', signed=True)
                        imuInfo.yaw = temp3 / 32768 * 180
                        imuInfo.pitch = temp2 / 32768 * 180
                        imuInfo.roll = temp1 / 32768 * 180
                        LogUtil.info(' roll angle  ', imuInfo.roll)
                        LogUtil.info('*' * 30)
                        LogUtil.info(' pitch angle  ', imuInfo.pitch)
                        LogUtil.info('*' * 30)
                        LogUtil.info(' yaw angle  ', imuInfo.yaw)
                        LogUtil.info('*' * 30)

                        if imuInfo.count_yaw == 0:  # 记录初始相位
                            imuInfo.yaw_init = imuInfo.yaw
                        imuInfo.record_angle.append(imuInfo.yaw - imuInfo.yaw_init)  # deg
                        data = data[st + length + 2:]
                        imuInfo.count_yaw += 1

                elif reserved == 81:  # 0x51, 丢弃加速度消息
                    if st + length + 1 < len(data):
                        ext_data = None
                        data = data[st + length + 2:]
                else:
                    data = data[st + 2:]
        except:
            return data, ext_omega, ext_angle
        if imuInfo.count_yaw % 100 == 0 and imuInfo.count_yaw > 0:
            self.save_data()
            LogUtil.info(len(imuInfo.record_omega), ' extract omega  ', ext_omega, imuInfo.omega_inte)
            LogUtil.info(len(imuInfo.record_angle), ' extract angle  ', ext_angle, imuInfo.yaw - imuInfo.yaw_init)
            LogUtil.info('*' * 30)
        return data, ext_omega, ext_angle

    def serial_readers(self,size=22):
        # port   : 串口端口
        # size   : 默认一次读取数据长度(bytes)
        
        ser = None
        port = self.port
        baud = self.baud
        imuInfo = self.imuInfo
        total = bytearray()
        while True:
            try:
                if not ser:
                    ser = serial.Serial(port, baud, timeout=1)

                if not ser.is_open:
                    ser.open()

                if not ser.is_open:
                    time.sleep(1)
                    continue

                tmp = ser.read(size)
                total.extend(tmp)
                total, ext_omega, ext_angle = self.extract_raw_data(total,imuInfo )
            except Exception as e:
                LogUtil.error(e)
                if ser:
                    ser.close()
            finally:
                time.sleep(0.01)

        return imuInfo.record_omega, imuInfo.record_angle

    def save_data(self,imuInfo):
        np.savez('record.npz', record_omega=imuInfo.record_omega, record_angle=imuInfo.record_angle)


    def get_serial_port(self):
        ports = list(serial.tools.list_ports.comports())
        for port in ports:
            LogUtil.info(ports.index(port), port)
        selected = -1
        while selected < 0 or selected >= len(ports):
            LogUtil.info("please input serial to use [start from 0]:")
            selected = int(input())
            LogUtil.info("selected: ", selected)

        port = ports[selected]
        LogUtil.info("use ", port)
        port = list(port)
        return port[0]


if __name__ == '__main__':

    port = "/dev/ttyUSB0"
    baudRate = 115200

    imuService = IMUService()
    imuService.imuInfo = IMUInfo()

    thread_rcv = threading.Thread(target=imuService.serial_readers)
    thread_rcv.start()

    while True:
        time.sleep(1)
