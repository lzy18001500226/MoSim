within DeviceDrivers.Packaging;
package SerialPackager

  type SerialPackager = Integer[2];

  function SerialPackager_constructor "Claim the memory"
    import Modelica;
    extends Modelica.Icons.Function;
    import DeviceDrivers.Packaging.SerialPackager;
    input Integer bufferSize = 16 * 1024;
    output DeviceDrivers.Packaging.SerialPackager.SerialPackager pkg;
  external "C" MDD_SerialPackagerConstructor(pkg, bufferSize)
  annotation (Include = "#include \"MDDSerialPackager.h\"", IncludeDirectory = "modelica://DeviceDrivers/Resources/Include", 
    __iti_dll = "ITI_MDD.dll", 
    __iti_dllNoExport = true);
  end SerialPackager_constructor;

  function SerialPackager_destructor "Free memory"
    import Modelica;
    extends Modelica.Icons.Function;
    import DeviceDrivers.Packaging.SerialPackager;
    input DeviceDrivers.Packaging.SerialPackager.SerialPackager pkg;
  external "C" MDD_SerialPackagerDestructor(pkg)
  annotation (Include = "#include \"MDDSerialPackager.h\"", 
    __iti_dll = "ITI_MDD.dll", 
    __iti_dllNoExport = true);
  end SerialPackager_destructor;

end SerialPackager;