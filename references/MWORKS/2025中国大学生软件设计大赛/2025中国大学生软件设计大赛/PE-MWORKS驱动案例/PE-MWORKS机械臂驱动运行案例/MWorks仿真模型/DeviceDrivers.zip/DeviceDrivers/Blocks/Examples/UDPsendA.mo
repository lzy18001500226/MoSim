﻿within DeviceDrivers.Blocks.Examples;
model UDPsendA
  "UDP发送"
  extends Modelica.Icons.Example;
  DeviceDrivers.Blocks.Packaging.SerialPackager.Packager packager(useBackwardPropagatedBufferSize = true, userBufferSize = 36) annotation (Placement(transformation(extent = {{-40, 62}, {-20, 82}})));
  DeviceDrivers.Blocks.Packaging.SerialPackager.AddReal addReal(
    nu = 1, 
    n = 10) annotation (Placement(transformation(extent = {{-40, 34}, {-20, 54}})));
  Modelica.Blocks.Sources.RealExpression source1(y = sin(0.2 * time)) annotation (Placement(transformation(origin = {-190.0, 148.00000000000006}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  DeviceDrivers.Blocks.Communication.UDPSend uDPSend(
    autoBufferSize = true, 
    userBufferSize = 36, 
    port_send = 10002, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {-29.999999999999996, 10.000000000000007}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));
  Modelica.Blocks.Sources.RealExpression source2(y = sin(0.4 * time)) annotation (Placement(transformation(origin = {-190.0, 122.00000000000003}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression source3(y = sin(0.6 * time)) annotation (Placement(transformation(origin = {-190.0, 96.00000000000001}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression source4(y = sin(1.3 * time)) annotation (Placement(transformation(origin = {-190.0, 70.00000000000001}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression source5(y = cos(0.17 * time)) annotation (Placement(transformation(origin = {-190.0, 43.99999999999999}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression source6(y = 2 * cos(0.2 * time)) annotation (Placement(transformation(origin = {-190.0, 17.99999999999997}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression source7(y = cos(0.13 * time)) annotation (Placement(transformation(origin = {-190.0, -8.000000000000036}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression source8(y = sin(0.2 * time) + 0.1 * time) annotation (Placement(transformation(origin = {-190.0, -34.00000000000002}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression source9(y = sin(0.35 * time + 0.8) - 0.05 * time) annotation (Placement(transformation(origin = {-190.0, -60.000000000000036}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression source10(y = sin(0.51 * time) + cos(time * 0.15 + 2)) annotation (Placement(transformation(origin = {-190.0, -86.00000000000009}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
equation 
  connect(packager.pkgOut, addReal.pkgIn) annotation (Line(origin = {-30.0, 58.0}, 
    points = {{0.0, 3.0}, {0.0, -3.0}}));
  annotation (
    Documentation(info = "<html>
<p>
The <code>uDPSend</code> block sends to the local port 10002. The <code>uDPReceive</code> block starts a background process that listens at port 10002. Consequently, the <code>uDPReceive</code> block receives what the <code>uDPSend</code> block sends.
</p>
<p>
<b>Note:</b> There is no causality between the <code>uDPSend</code> block and the <code>uDPReceive</code> block. Therefore the execution order of the blocks is not determined. Additionally, the <code>uDPReceive</code> block starts an own receiving thread, so that the time the data was received is not equal to the time the external function within the <code>uDPReceive</code> block was called. This indeterminism may also show up in the plots.
</p>
</html>"), 
    experiment(StartTime = 0, StopTime = 300, Interval = 0.002, Algorithm = Dassl, Tolerance = 0.0001, DoublePrecision = true, StoreEventValue = false));



  connect(addReal.pkgOut[1], uDPSend.pkgIn)
    annotation (Line(origin = {-30.0, 27.0}, 
      points = {{0.0, 6.0}, {0.0, -6.0}}, 
      color = {0, 0, 0}));
  connect(source1.y, addReal.u[1])
    annotation (Line(origin = {-110.0, 96.0}, 
      points = {{-69.0, 52.0}, {10.0, 52.0}, {10.0, -52.0}, {68.0, -52.0}}, 
      color = {0, 0, 127}));
  connect(source2.y, addReal.u[2])
    annotation (Line(origin = {-110.0, 83.0}, 
      points = {{-69.0, 39.0}, {10.0, 39.0}, {10.0, -39.0}, {68.0, -39.0}}, 
      color = {0, 0, 127}));
  connect(source3.y, addReal.u[3])
    annotation (Line(origin = {-110.0, 70.0}, 
      points = {{-69.0, 26.0}, {10.0, 26.0}, {10.0, -26.0}, {68.0, -26.0}}, 
      color = {0, 0, 127}));
  connect(source4.y, addReal.u[4])
    annotation (Line(origin = {-110.0, 57.0}, 
      points = {{-69.0, 13.0}, {10.0, 13.0}, {10.0, -13.0}, {68.0, -13.0}}, 
      color = {0, 0, 127}));
  connect(source5.y, addReal.u[5])
    annotation (Line(origin = {-110.0, 44.0}, 
      points = {{-69.0, 0.0}, {68.0, 0.0}}, 
      color = {0, 0, 127}));
  connect(source6.y, addReal.u[6])
    annotation (Line(origin = {-110.0, 31.0}, 
      points = {{-69.0, -13.0}, {10.0, -13.0}, {10.0, 13.0}, {68.0, 13.0}}, 
      color = {0, 0, 127}));
  connect(source7.y, addReal.u[7])
    annotation (Line(origin = {-110.0, 18.0}, 
      points = {{-69.0, -26.0}, {10.0, -26.0}, {10.0, 26.0}, {68.0, 26.0}}, 
      color = {0, 0, 127}));
  connect(source8.y, addReal.u[8])
    annotation (Line(origin = {-110.0, 5.0}, 
      points = {{-69.0, -39.0}, {10.0, -39.0}, {10.0, 39.0}, {68.0, 39.0}}, 
      color = {0, 0, 127}));
  connect(source9.y, addReal.u[9])
    annotation (Line(origin = {-110.0, -8.0}, 
      points = {{-69.0, -52.0}, {10.0, -52.0}, {10.0, 52.0}, {68.0, 52.0}}, 
      color = {0, 0, 127}));
  connect(source10.y, addReal.u[10])
    annotation (Line(origin = {-110.0, -21.0}, 
      points = {{-69.0, -65.0}, {10.0, -65.0}, {10.0, 65.0}, {68.0, 65.0}}, 
      color = {0, 0, 127}));
end UDPsendA;