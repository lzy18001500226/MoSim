within DeviceDrivers.Utilities;
package Types "Custom type definitions"
  extends Modelica.Icons.TypesPackage;
  type SignalType = enumeration(
    integer  "Integer value", 
    float  "IEEE float value", 
    double  "IEEE double value") "Encoded data type";
  type ByteOrder = enumeration(
    LE  "Little endian", 
    BE  "Big endian") "Byte order";



end Types;