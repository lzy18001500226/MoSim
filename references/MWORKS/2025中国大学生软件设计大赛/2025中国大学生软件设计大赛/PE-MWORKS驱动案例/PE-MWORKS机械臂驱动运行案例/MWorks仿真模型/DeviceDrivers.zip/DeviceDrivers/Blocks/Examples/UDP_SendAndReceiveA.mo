﻿within DeviceDrivers.Blocks.Examples;
model UDP_SendAndReceiveA "UDP-同时发送与接收数据"
  extends Modelica.Icons.Example;
  annotation (experiment(Algorithm = Dassl, Interval = 0.001, StartTime = 0, StopTime = 300, Tolerance = 0.0001));
  Componment.PeComponment.PETypeRecv pETypeRecv
    annotation (Placement(transformation(origin = {40.000000000000014, 3.552713678800501e-15}, 
      extent = {{-20.0, -19.999999999999996}, {19.999999999999993, 19.999999999999996}})));
equation 
end UDP_SendAndReceiveA;