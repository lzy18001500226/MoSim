#pragma once

#ifdef NAME_VALUE_DLL_OUT
#define NETWORK_API __declspec(dllexport)
#else
#define NETWORK_API __declspec(dllimport)
#endif // NAME_VALUE_API

#ifdef __cplusplus
extern "C" {
#endif

NETWORK_API void *CreateNameAndValue();
NETWORK_API void DestroyNameAndValue(void *obj);
NETWORK_API void AddValue(void * obj, char * varName, double value);
NETWORK_API void RemoveVar(void* obj,char* varName);
NETWORK_API void UpdateValue(void* obj,char*, double value);
NETWORK_API void Update2dTableValue(void* obj,char* tableName,double* tableValues,int rowCount,int colCount);
NETWORK_API void Update1dTableValue(void* obj,char* tableName,double* tableValues,int colCount);
NETWORK_API int GetValue(void * obj, char * varName, double* value);
NETWORK_API int Get1dTableValue(void * obj, char * varName, int dateLen,double* outValue);
NETWORK_API int Get2dTableValue(void * obj, char * varName, int dateRows,int dataCols, double* outValue);
NETWORK_API int Get2dFlexibleArrayToFile(void * obj, char * varName, char * filePath);
NETWORK_API int Get1dFlexibleArrayToFile(void * obj, char * varName, char * filePath);
NETWORK_API int ClearValues(void * obj);


NETWORK_API void* CreateSocket(char* bindAddress,int listenPost);
NETWORK_API void DestorySocket(void * obj);
//�ɹ�����1��ʧ�ܷ���0
NETWORK_API int SendData(void * socket,void* dataObj,char* remoteAddress,unsigned short remotePort,double simTime);
//�ɹ�����1��ʧ�ܷ���0
NETWORK_API int RecvData(void * socket,void* dataObj,char* remoteAddress);
//�첽�ȴ���������
NETWORK_API int WaitResponse(void * socket, const char* response, char* remoteAddress);

NETWORK_API int RequestAndWait(const char* requsetName, const char* responseName,int requestVal,unsigned short remotePort,unsigned short recvPort,double simTime);
#ifdef __cplusplus
}
#endif