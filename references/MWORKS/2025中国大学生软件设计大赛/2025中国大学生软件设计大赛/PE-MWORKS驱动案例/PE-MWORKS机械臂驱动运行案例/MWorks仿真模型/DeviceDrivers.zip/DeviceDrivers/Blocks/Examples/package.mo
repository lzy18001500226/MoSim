within DeviceDrivers.Blocks;
package Examples "ʾ��ģ�Ϳ�"
  extends Modelica.Icons.ExamplesPackage;
end Examples;