﻿within DeviceDrivers.Blocks;
package Componment "功能组件"
  class NameValue
    extends ExternalObject;
    function constructor
      output NameValue valObj;
    external "C" valObj = CreateNameAndValue(valObj) 
    annotation (Library = "Utilities_Network");
    end constructor;
    function destructor
      input NameValue valObj;
    external "C" DestroyNameAndValue(valObj) 
    annotation (Library = "Utilities_Network");
    end destructor;

    annotation (Diagram(coordinateSystem(extent = {{-140.0, -100.0}, {140.0, 100.0}}, 
      preserveAspectRatio = false, 
      grid = {2.0, 2.0})), 
      Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        preserveAspectRatio = false, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        lineColor = {200, 200, 200}, 
        fillColor = {248, 248, 248}, 
        fillPattern = FillPattern.HorizontalCylinder, 
        extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        radius = 25.0), Rectangle(origin = {0.0, 0.0}, 
        lineColor = {128, 128, 128}, 
        extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        radius = 25.0), Text(origin = {0.0, 0.0}, 
        lineColor = {0, 128, 0}, 
        extent = {{-100.0, 100.0}, {100.0, -100.0}}, 
        textString = "C", 
        fontName = "Times New Roman", 
        textStyle = {TextStyle.None}, 
        textColor = {0, 128, 0})}));

  end NameValue;
  class Socket "对socket的封装"
    extends ExternalObject;
    function constructor
      input String local_ip;
      input Integer local_port;
      output Socket socketObj;
    external "C" socketObj = CreateSocket(local_ip, local_port) 
    annotation (Library = "Utilities_Network");
    end constructor;
    function destructor
      input Socket socketobj;
    external "C" DestorySocket(socketobj) 
    annotation (Library = "Utilities_Network");
    end destructor;



    annotation (Diagram(coordinateSystem(extent = {{-140.0, -100.0}, {140.0, 100.0}}, 
      preserveAspectRatio = false, 
      grid = {2.0, 2.0})), 
      Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        preserveAspectRatio = false, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        lineColor = {200, 200, 200}, 
        fillColor = {248, 248, 248}, 
        fillPattern = FillPattern.HorizontalCylinder, 
        extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        radius = 25.0), Rectangle(origin = {0.0, 0.0}, 
        lineColor = {128, 128, 128}, 
        extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        radius = 25.0), Text(origin = {0.0, 0.0}, 
        lineColor = {0, 128, 0}, 
        extent = {{-100.0, 100.0}, {100.0, -100.0}}, 
        textString = "C", 
        fontName = "Times New Roman", 
        textStyle = {TextStyle.None}, 
        textColor = {0, 128, 0})}));
  end Socket;
  package PeComponment
    model PETypeEncodeAndSend
      // 高级
      parameter String localAddress = "192.168.88.172" 
        annotation (Dialog(tab = "高级"));
      parameter String remoteAddress = "192.168.89.44" 
        annotation (Dialog(tab = "高级"));
      parameter Integer localPort = 5690 
        annotation (Dialog(tab = "高级"));
      parameter Integer remoteport = 5820 
        annotation (Dialog(tab = "高级"));
      parameter Modelica.SIunits.Time deltaT = 0.005 "通信周期" 
        annotation (Dialog(tab = "高级"));

      // 组件
      DeviceDrivers.Blocks.Componment.NameValue valObj = NameValue();
      DeviceDrivers.Blocks.Componment.Socket socketObj = DeviceDrivers.Blocks.Componment.Socket(localAddress, localPort);

      // 接口
      DataBus dataBus "数据总线" annotation (Placement(transformation(origin = {-100.0, 0.0}, 
        extent = {{20.0, -20.0}, {-20.0, 20.0}}, 
        rotation = -90.0), 
        iconTransformation(origin = {-100.0, 0.0}, 
          extent = {{20.0, -20.0}, {-20.0, 20.0}}, 
          rotation = -90.0)));
    protected
      Boolean isInited;
      annotation (Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        fillColor = {246, 255, 230}, 
        fillPattern = FillPattern.Solid, 
        lineThickness = 0.5, 
        extent = {{-100.0, 100.0}, {100.0, -100.0}}, 
        radius = 10.0), Line(origin = {11.999999999999986, -6.661338147750939e-16}, 
        points = {{-80.0, 0.0}, {80.0, 0.0}}, 
        color = {65, 65, 65}), Ellipse(origin = {-68.0, -6.661338147750939e-16}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {-28.000000000000007, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {1.9999999999999858, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {31.999999999999986, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {62.0, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Line(origin = {-28.000000000000007, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {1.9999999999999858, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {31.999999999999986, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {62.0, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65})}), 
        experiment(Algorithm = Dassl, Interval = 0.001, StartTime = 0, StopTime = 300, Tolerance = 0.0001));
    algorithm
      when initial() then
        isInited := false;
      end when;
      when sample(0, deltaT) then
        if not isInited then
          //等待初始化完成
          DeviceDrivers.Blocks.Functions.WaitResponse(socketObj, "res_InitSucceed", remoteAddress);
          isInited := true;
        else
          // 发送数据
          //发送标量
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Time", dataBus.Time);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a1", dataBus.T_a1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a2", dataBus.T_a2);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a3", dataBus.T_a3);
          //发送向量
          // DeviceDrivers.Blocks.Functions.Update1DTableValue(valObj, "i", dataBus.i, 3);
          // DeviceDrivers.Blocks.Functions.Update1DTableValue(valObj, "v", dataBus.v, 3);
          //发送矩阵
          //    DeviceDrivers.Blocks.Functions.Update2DTableValue(valObj, "X", dataBus.X, 2, 5);
          // IP及端口
          DeviceDrivers.Blocks.Functions.SendData(socketObj, valObj, remoteAddress, remoteport);
          //DeviceDrivers.Blocks.Functions.SendData(socketObj, valObj, remoteAddress, 5566);
        end if;
      end when;
    end PETypeEncodeAndSend;
    model PETypeRecv
      // 高级
      parameter String localAddress = "127.0.0.1" 
        annotation (Dialog(tab = "高级"));
      parameter String remoteAddress = "127.0.0.1" 
        annotation (Dialog(tab = "高级"));
      parameter Integer localPort = 5820 
        annotation (Dialog(tab = "高级"));

      parameter Modelica.SIunits.Time deltaT = 0.005 "通信周期" 
        annotation (Dialog(tab = "高级"));
      // 组件
      Componment.NameValue valObj = NameValue();
      Componment.Socket socketObj = Componment.Socket(localAddress, localPort);
      Boolean receiveOK;
      Boolean isGetOk[4];
      PeOutput peOutput annotation (Placement(transformation(origin = {100.0, 0.0}, 
        extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
        rotation = -90.0)));
      // protected 
      //   Integer transPort = 5555;
      annotation (Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        fillColor = {255, 170, 127}, 
        fillPattern = FillPattern.Solid, 
        lineThickness = 0.5, 
        extent = {{-100.0, 100.0}, {100.0, -100.0}}, 
        radius = 10.0), Line(origin = {11.999999999999986, -6.661338147750939e-16}, 
        points = {{-80.0, 0.0}, {80.0, 0.0}}, 
        color = {65, 65, 65}), Ellipse(origin = {-68.0, -6.661338147750939e-16}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {-28.000000000000007, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {1.9999999999999858, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {31.999999999999986, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {62.0, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Line(origin = {-28.000000000000007, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {1.9999999999999858, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {31.999999999999986, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {62.0, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65})}), 
        experiment(Algorithm = Dassl, Interval = 0.001, StartTime = 0, StopTime = 150, Tolerance = 0.0001));
    algorithm
      when sample(0, deltaT) then
        receiveOK := DeviceDrivers.Blocks.Functions.RecvData(socketObj, valObj, remoteAddress);
        (isGetOk[1],peOutput.n) := DeviceDrivers.Blocks.Functions.GetData(valObj, "n");
        (isGetOk[2],peOutput.i) := DeviceDrivers.Blocks.Functions.GetData(valObj, "i");
        (isGetOk[3],peOutput.T_w) := DeviceDrivers.Blocks.Functions.GetData(valObj, "T_w");
        (isGetOk[4],peOutput.T_e) := DeviceDrivers.Blocks.Functions.GetData(valObj, "T_e");
      end when;
    end PETypeRecv;
    expandable connector DataBus "数据总线接口"
      //Real w "时间";
    Real R1_angle1;
    Real R1_angle2;
    Real R1_angle3;
    Real R1_angle4;
    Real R1_angle5;
    Real R1_angle6;

    Real R1_x1;
    Real R1_x2;


    Real R2_angle1;
    Real R2_angle2;
    Real R2_angle3;
    Real R2_angle4;
    Real R2_angle5;
    Real R2_angle6;

    Real R2_x1;
    Real R2_x2;

    Real R3_angle1;
    Real R3_angle2;
    Real R3_angle3;
    Real R3_angle4;
    Real R3_angle5;
    Real R3_angle6;

    Real R3_x1;
    Real R3_x2;



      annotation (Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        initialScale = 0.2, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        lineColor = {255, 215, 136}, 
        lineThickness = 0.5, 
        extent = {{-20.0, -2.0}, {20.0, 2.0}}), Polygon(origin = {0.0, 0.0}, 
        lineColor = {0, 0, 0}, 
        fillColor = {85, 255, 255}, 
        fillPattern = FillPattern.Solid, 
        points = {{-80.0, 50.0}, {80.0, 50.0}, {100.0, 30.0}, {80.0, -40.0}, {60.0, -50.0}, {-60.0, -50.0}, {-80.0, -40.0}, {-100.0, 30.0}}, 
        smooth = Smooth.Bezier), Ellipse(origin = {-60.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Ellipse(origin = {0.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Ellipse(origin = {60.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Ellipse(origin = {-30.0, -20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Ellipse(origin = {30.0, -20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Text(origin = {0.0, 80.0}, 
        lineColor = {0, 0, 0}, 
        extent = {{-100.0, -20.0}, {100.0, 20.0}}, 
        textString = "%name", 
        textStyle = {TextStyle.None}, 
        textColor = {0, 0, 0})}), Diagram(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
          initialScale = 0.2, 
          grid = {2.0, 2.0}), graphics = {Polygon(origin = {0.0, 0.0}, 
          lineColor = {0, 0, 0}, 
          fillColor = {85, 255, 255}, 
          fillPattern = FillPattern.Solid, 
          points = {{-40.0, 25.0}, {40.0, 25.0}, {50.0, 15.0}, {40.0, -20.0}, {30.0, -25.0}, {-30.0, -25.0}, {-40.0, -20.0}, {-50.0, 15.0}}, 
          smooth = Smooth.Bezier), Ellipse(origin = {-30.0, 10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, -2.5}, {2.5, 2.5}}), Ellipse(origin = {0.0, 10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, 2.5}, {2.5, -2.5}}), Ellipse(origin = {30.0, 10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, 2.5}, {2.5, -2.5}}), Ellipse(origin = {-15.0, -10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, 2.5}, {2.5, -2.5}}), Ellipse(origin = {15.0, -10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, 2.5}, {2.5, -2.5}}), Text(origin = {0.0, 55.0}, 
          lineColor = {0, 0, 0}, 
          extent = {{-100.0, 15.0}, {100.0, -15.0}}, 
          textString = "%name", 
          textStyle = {TextStyle.None}, 
          textColor = {0, 0, 0})}));
    end DataBus;



    expandable connector PeOutput
      Real n "转速";
      Real i "电流";
      Real T_w "水温";
      Real T_e "环境温度";
      annotation (Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        grid = {2.0, 2.0}), graphics = {Polygon(origin = {0.0, 0.0}, 
        lineColor = {85, 255, 0}, 
        fillColor = {85, 255, 0}, 
        fillPattern = FillPattern.Solid, 
        points = {{-80.0, 50.0}, {80.0, 50.0}, {100.0, 30.0}, {80.0, -40.0}, {60.0, -50.0}, {-60.0, -50.0}, {-80.0, -40.0}, {-100.0, 30.0}, {-80.0, 50.0}}), Ellipse(origin = {-50.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, 5.0}, {5.0, -5.0}}), Ellipse(origin = {50.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, 5.0}, {5.0, -5.0}}), Ellipse(origin = {-25.0, -20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, 5.0}, {5.0, -5.0}}), Ellipse(origin = {0.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, 5.0}, {5.0, -5.0}}), Ellipse(origin = {25.0, -20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, 5.0}, {5.0, -5.0}})}));
    end PeOutput;

    model DataSource "信号源"
      Real n "转速";
      Real i "电流";
      Real T_w "水温";
      Real T_e "环境温度";
    equation
      n = 0.3 * time + 50 + 10 * sin(time * 0.2);
      i = 20 + 8 * sin(time * 0.6);
      T_w = 30 + 5 * cos(time * 0.15);
      T_e = 40 + 10 * sin(time * 0.25);
      annotation (Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        initialScale = 0.2, 
        grid = {2.0, 2.0})), 
        Diagram(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
          initialScale = 0.2, 
          grid = {2.0, 2.0})));
    end DataSource;
    model PETypeEncodeAndSend1
      // 高级
      parameter String localAddress = "127.0.0.1" 
        annotation (Dialog(tab = "高级"));
      parameter String remoteAddress = "127.0.0.1" 
        annotation (Dialog(tab = "高级"));
      parameter Integer localPort = 10002 
        annotation (Dialog(tab = "高级"));
      parameter Integer remoteport = 32701 
        annotation (Dialog(tab = "高级"));
      parameter Modelica.SIunits.Time deltaT = 0.005 "通信周期" 
        annotation (Dialog(tab = "高级"));

      // 组件
      DeviceDrivers.Blocks.Componment.NameValue valObj = NameValue();
      DeviceDrivers.Blocks.Componment.Socket socketObj = DeviceDrivers.Blocks.Componment.Socket(localAddress, localPort);

      // 接口
      DataBus dataBus "数据总线" annotation (Placement(transformation(origin = {-100.0, 0.0}, 
        extent = {{20.0, -20.0}, {-20.0, 20.0}}, 
        rotation = -90.0), 
        iconTransformation(origin = {-100.0, 0.0}, 
          extent = {{20.0, -20.0}, {-20.0, 20.0}}, 
          rotation = -90.0)));
    protected
      Boolean isInited;
      annotation (Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        fillColor = {246, 255, 230}, 
        fillPattern = FillPattern.Solid, 
        lineThickness = 0.5, 
        extent = {{-100.0, 100.0}, {100.0, -100.0}}, 
        radius = 10.0), Line(origin = {11.999999999999986, -6.661338147750939e-16}, 
        points = {{-80.0, 0.0}, {80.0, 0.0}}, 
        color = {65, 65, 65}), Ellipse(origin = {-68.0, -6.661338147750939e-16}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {-28.000000000000007, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {1.9999999999999858, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {31.999999999999986, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {62.0, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Line(origin = {-28.000000000000007, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {1.9999999999999858, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {31.999999999999986, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {62.0, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65})}), 
        experiment(Algorithm = Dassl, Interval = 0.001, StartTime = 0, StopTime = 300, Tolerance = 0.0001));
    algorithm
      when initial() then
        isInited := false;
      end when;
      //
      // dataBus.Time := time;
      // dataBus.T_a1 := 12 * sin(time);
      // dataBus.T_a2 := 15 * cos(1.5 * time);
      // dataBus.T_a3 := sin(time ^ 2 + cos(time));
      //
      when sample(0, deltaT) then
        if not isInited then
          //等待初始化完成
          DeviceDrivers.Blocks.Functions.WaitResponse(socketObj, "res_InitSucceed", remoteAddress);
          isInited := true;
        else
          // 发送数据
          //发送标量
    // {Missile_X, Missile_Y, Missile_Z, Missile_Speed, Missile_angle1}
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile_X", dataBus.Missile_X);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile_Y", dataBus.Missile_Y);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile_Z", dataBus.Missile_Z);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile_angle1", dataBus.Missile_angle1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile_Speed", dataBus.Missile_Speed);
          //
           DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "First_DH", dataBus.First_DH);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "second_DH", dataBus.second_DH);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "First_FL", dataBus.First_FL);
             DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "third_DH", dataBus.third_DH);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "second_FL", dataBus.second_FL);
    ///
         DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "ZLZ_FL", dataBus.ZLZ_FL);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile_DH", dataBus.Missile_DH);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "third_FL", dataBus.third_FL);
             DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile1_FL", dataBus.Missile1_FL);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile2_FL", dataBus.Missile2_FL);

          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "Missile3_FL", dataBus.Missile3_FL);
                 DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "FDC_FL", dataBus.FDC_FL);


          //发送向量
          // DeviceDrivers.Blocks.Functions.Update1DTableValue(valObj, "i", dataBus.i, 3);
          // DeviceDrivers.Blocks.Functions.Update1DTableValue(valObj, "v", dataBus.v, 3);
          //发送矩阵
          //    DeviceDrivers.Blocks.Functions.Update2DTableValue(valObj, "X", dataBus.X, 2, 5);
          // IP及端口
          DeviceDrivers.Blocks.Functions.SendData(socketObj, valObj, remoteAddress, remoteport);
        end if;
      end when;
    end PETypeEncodeAndSend1;
    model PETypeEncodeAndSend_A
      // 高级
      parameter String localAddress = "192.168.88.172" 
        annotation(Dialog(tab = "高级"));
      parameter String remoteAddress = "192.168.89.44" 
        annotation(Dialog(tab = "高级"));
      parameter Integer localPort = 5690 
        annotation(Dialog(tab = "高级"));
      parameter Integer remoteport = 5820 
        annotation(Dialog(tab = "高级"));
      parameter Modelica.SIunits.Time deltaT = 0.005 "通信周期" 
        annotation(Dialog(tab = "高级"));

      // 组件
      DeviceDrivers.Blocks.Componment.NameValue valObj = NameValue();
      DeviceDrivers.Blocks.Componment.Socket socketObj = DeviceDrivers.Blocks.Componment.Socket(localAddress, localPort);

      // 接口
      DataBus1 dataBus "数据总线" annotation(Placement(transformation(origin = {-100.0, 0.0}, 
        extent = {{20.0, -20.0}, {-20.0, 20.0}}, 
        rotation = -90.0), 
        iconTransformation(origin = {-100.0, 0.0}, 
        extent = {{20.0, -20.0}, {-20.0, 20.0}}, 
        rotation = -90.0)));
    protected
      Boolean isInited;
      annotation(Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        fillColor = {246, 255, 230}, 
        fillPattern = FillPattern.Solid, 
        lineThickness = 0.5, 
        extent = {{-100.0, 100.0}, {100.0, -100.0}}, 
        radius = 10.0), Line(origin = {11.999999999999986, -6.661338147750939e-16}, 
        points = {{-80.0, 0.0}, {80.0, 0.0}}, 
        color = {65, 65, 65}), Ellipse(origin = {-68.0, -6.661338147750939e-16}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {-28.000000000000007, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {1.9999999999999858, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {31.999999999999986, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {62.0, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Line(origin = {-28.000000000000007, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {1.9999999999999858, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {31.999999999999986, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {62.0, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65})}), 
        experiment(Algorithm = Dassl, Interval = 0.001, StartTime = 0, StopTime = 300, Tolerance = 0.0001));
    algorithm
      when initial() then
        isInited := false;
      end when;
      when sample(0, deltaT) then
        if not isInited then
          //等待初始化完成
          DeviceDrivers.Blocks.Functions.WaitResponse(socketObj, "res_InitSucceed", remoteAddress);
          isInited := true;
        else
          // 发送数据
          //发送标量
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "angle1", dataBus.angle1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "angle2", dataBus.angle2);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "angle3", dataBus.angle3);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "angle4", dataBus.angle4);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "angle5", dataBus.angle5);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "angle6", dataBus.angle6);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "x1", dataBus.x1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "x2", dataBus.x2);
          // DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a1", dataBus.T_a1);
          // DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a2", dataBus.T_a2);
          // DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a3", dataBus.T_a3);
          //发送向量
          // DeviceDrivers.Blocks.Functions.Update1DTableValue(valObj, "i", dataBus.i, 3);
          // DeviceDrivers.Blocks.Functions.Update1DTableValue(valObj, "v", dataBus.v, 3);
          //发送矩阵
          //    DeviceDrivers.Blocks.Functions.Update2DTableValue(valObj, "X", dataBus.X, 2, 5);
          // IP及端口
          DeviceDrivers.Blocks.Functions.SendData(socketObj, valObj, remoteAddress, remoteport);
        //DeviceDrivers.Blocks.Functions.SendData(socketObj, valObj, remoteAddress, 5566);
        end if;
      end when;
    end PETypeEncodeAndSend_A;
    model PETypeEncodeAndSend_RobotAsse
      // 高级
      parameter String localAddress = "192.168.88.172" 
        annotation(Dialog(tab = "高级"));
      parameter String remoteAddress = "192.168.89.44" 
        annotation(Dialog(tab = "高级"));
      parameter Integer localPort = 5690 
        annotation(Dialog(tab = "高级"));
      parameter Integer remoteport = 5820 
        annotation(Dialog(tab = "高级"));
      parameter Modelica.SIunits.Time deltaT = 0.005 "通信周期" 
        annotation(Dialog(tab = "高级"));

      // 组件
      DeviceDrivers.Blocks.Componment.NameValue valObj = NameValue();
      DeviceDrivers.Blocks.Componment.Socket socketObj = DeviceDrivers.Blocks.Componment.Socket(localAddress, localPort);

      // 接口
      DataBus dataBus "数据总线" annotation(Placement(transformation(origin = {-100.0, 0.0}, 
        extent = {{20.0, -20.0}, {-20.0, 20.0}}, 
        rotation = -90.0), 
        iconTransformation(origin = {-100.0, 0.0}, 
        extent = {{20.0, -20.0}, {-20.0, 20.0}}, 
        rotation = -90.0)));
    protected
      Boolean isInited;
      annotation(Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        fillColor = {246, 255, 230}, 
        fillPattern = FillPattern.Solid, 
        lineThickness = 0.5, 
        extent = {{-100.0, 100.0}, {100.0, -100.0}}, 
        radius = 10.0), Line(origin = {11.999999999999986, -6.661338147750939e-16}, 
        points = {{-80.0, 0.0}, {80.0, 0.0}}, 
        color = {65, 65, 65}), Ellipse(origin = {-68.0, -6.661338147750939e-16}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {-28.000000000000007, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {1.9999999999999858, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {31.999999999999986, 30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Rectangle(origin = {62.0, -30.0}, 
        lineColor = {65, 65, 65}, 
        fillColor = {65, 65, 65}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-10.0, 10.0}, {10.0, -10.0}}), Line(origin = {-28.000000000000007, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {1.9999999999999858, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {31.999999999999986, 9.999999999999998}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65}), Line(origin = {62.0, -10.000000000000002}, 
        points = {{0.0, -10.0}, {0.0, 10.0}}, 
        color = {65, 65, 65})}), 
        experiment(Algorithm = Dassl, Interval = 0.001, StartTime = 0, StopTime = 300, Tolerance = 0.0001));
    algorithm
      when initial() then
        isInited := false;
      end when;
      when sample(0, deltaT) then
        if not isInited then
          //等待初始化完成
          DeviceDrivers.Blocks.Functions.WaitResponse(socketObj, "res_InitSucceed", remoteAddress);
          isInited := true;
        else
          // 发送数据
          //发送标量
          //Robot1
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R1_angle1", dataBus.R1_angle1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R1_angle2", dataBus.R1_angle2);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R1_angle3", dataBus.R1_angle3);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R1_angle4", dataBus.R1_angle4);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R1_angle5", dataBus.R1_angle5);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R1_angle6", dataBus.R1_angle6);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R1_x1", dataBus.R1_x1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R1_x2", dataBus.R1_x2);

          //Robot2
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R2_angle1", dataBus.R2_angle1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R2_angle2", dataBus.R2_angle2);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R2_angle3", dataBus.R2_angle3);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R2_angle4", dataBus.R2_angle4);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R2_angle5", dataBus.R2_angle5);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R2_angle6", dataBus.R2_angle6);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R2_x1", dataBus.R2_x1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R2_x2", dataBus.R2_x2);

          //Robot3
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R3_angle1", dataBus.R3_angle1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R3_angle2", dataBus.R3_angle2);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R3_angle3", dataBus.R3_angle3);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R3_angle4", dataBus.R3_angle4);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R3_angle5", dataBus.R3_angle5);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R3_angle6", dataBus.R3_angle6);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R3_x1", dataBus.R3_x1);
          DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "R3_x2", dataBus.R3_x2);


          // DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a1", dataBus.T_a1);
          // DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a2", dataBus.T_a2);
          // DeviceDrivers.Blocks.Functions.UpdateValue(valObj, "T_a3", dataBus.T_a3);
          //发送向量
          // DeviceDrivers.Blocks.Functions.Update1DTableValue(valObj, "i", dataBus.i, 3);
          // DeviceDrivers.Blocks.Functions.Update1DTableValue(valObj, "v", dataBus.v, 3);
          //发送矩阵
          //    DeviceDrivers.Blocks.Functions.Update2DTableValue(valObj, "X", dataBus.X, 2, 5);
          // IP及端口
          DeviceDrivers.Blocks.Functions.SendData(socketObj, valObj, remoteAddress, remoteport);
        //DeviceDrivers.Blocks.Functions.SendData(socketObj, valObj, remoteAddress, 5566);
        end if;
      end when;
    end PETypeEncodeAndSend_RobotAsse;
    expandable connector DataBus1 "数据总线接口single"
      //Real w "时间";
    Real angle1;
    Real angle2;
    Real angle3;
    Real angle4;
    Real angle5;
    Real angle6;

    Real x1;
    Real x2;






      annotation (Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
        initialScale = 0.2, 
        grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
        lineColor = {255, 215, 136}, 
        lineThickness = 0.5, 
        extent = {{-20.0, -2.0}, {20.0, 2.0}}), Polygon(origin = {0.0, 0.0}, 
        lineColor = {0, 0, 0}, 
        fillColor = {85, 255, 255}, 
        fillPattern = FillPattern.Solid, 
        points = {{-80.0, 50.0}, {80.0, 50.0}, {100.0, 30.0}, {80.0, -40.0}, {60.0, -50.0}, {-60.0, -50.0}, {-80.0, -40.0}, {-100.0, 30.0}}, 
        smooth = Smooth.Bezier), Ellipse(origin = {-60.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Ellipse(origin = {0.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Ellipse(origin = {60.0, 20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Ellipse(origin = {-30.0, -20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Ellipse(origin = {30.0, -20.0}, 
        fillPattern = FillPattern.Solid, 
        extent = {{-5.0, -5.0}, {5.0, 5.0}}), Text(origin = {0.0, 80.0}, 
        lineColor = {0, 0, 0}, 
        extent = {{-100.0, -20.0}, {100.0, 20.0}}, 
        textString = "%name", 
        textStyle = {TextStyle.None}, 
        textColor = {0, 0, 0})}), Diagram(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
          initialScale = 0.2, 
          grid = {2.0, 2.0}), graphics = {Polygon(origin = {0.0, 0.0}, 
          lineColor = {0, 0, 0}, 
          fillColor = {85, 255, 255}, 
          fillPattern = FillPattern.Solid, 
          points = {{-40.0, 25.0}, {40.0, 25.0}, {50.0, 15.0}, {40.0, -20.0}, {30.0, -25.0}, {-30.0, -25.0}, {-40.0, -20.0}, {-50.0, 15.0}}, 
          smooth = Smooth.Bezier), Ellipse(origin = {-30.0, 10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, -2.5}, {2.5, 2.5}}), Ellipse(origin = {0.0, 10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, 2.5}, {2.5, -2.5}}), Ellipse(origin = {30.0, 10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, 2.5}, {2.5, -2.5}}), Ellipse(origin = {-15.0, -10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, 2.5}, {2.5, -2.5}}), Ellipse(origin = {15.0, -10.0}, 
          fillPattern = FillPattern.Solid, 
          extent = {{-2.5, 2.5}, {2.5, -2.5}}), Text(origin = {0.0, 55.0}, 
          lineColor = {0, 0, 0}, 
          extent = {{-100.0, 15.0}, {100.0, -15.0}}, 
          textString = "%name", 
          textStyle = {TextStyle.None}, 
          textColor = {0, 0, 0})}));
    end DataBus1;
  end PeComponment;
end Componment;