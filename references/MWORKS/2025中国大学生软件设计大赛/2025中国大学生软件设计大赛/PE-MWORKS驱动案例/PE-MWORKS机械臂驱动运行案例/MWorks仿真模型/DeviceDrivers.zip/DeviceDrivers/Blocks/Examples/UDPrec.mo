﻿within DeviceDrivers.Blocks.Examples;
model UDPrec
  "UDP接收"
  extends Modelica.Icons.Example;
  DeviceDrivers.Blocks.Communication.UDPReceive uDPReceive(
    autoBufferSize = true, 
    userBufferSize = 36, 
    port_recv = 10002, 
    sampleTime = 0.01)


    annotation (Placement(transformation(
      origin = {40, 50}, 
      extent = {{-10, -10}, {10, 10}}, 
      rotation = 270)));
  DeviceDrivers.Blocks.Packaging.SerialPackager.GetReal getReal(
    nu = 1, 
    n = 3) annotation (Placement(transformation(extent = {{30, 10}, {50, 30}})));
  DeviceDrivers.Blocks.Packaging.SerialPackager.GetInteger getInteger annotation (Placement(transformation(extent = {{30, -48}, {50, -28}})));



  Packaging.SerialPackager.GetFloat getFloat(
    nu = 1, 
    n = 2) annotation (Placement(transformation(extent = {{30, -18}, {50, 2}})));
equation 
  connect(uDPReceive.pkgOut, getReal.pkgIn) annotation (Line(
    points = {{40, 39.2}, {40, 30.8}}));
  connect(getReal.pkgOut[1], getFloat.pkgIn) annotation (Line(
    points = {{40, 9.2}, {40, 2.8}}));
  connect(getInteger.pkgIn, getFloat.pkgOut[1]) annotation (Line(
    points = {{40, -27.2}, {40, -18.8}}));
  annotation (
    Documentation(info = "<html>
<p>
The <code>uDPSend</code> block sends to the local port 10002. The <code>uDPReceive</code> block starts a background process that listens at port 10002. Consequently, the <code>uDPReceive</code> block receives what the <code>uDPSend</code> block sends.
</p>
<p>
<b>Note:</b> There is no causality between the <code>uDPSend</code> block and the <code>uDPReceive</code> block. Therefore the execution order of the blocks is not determined. Additionally, the <code>uDPReceive</code> block starts an own receiving thread, so that the time the data was received is not equal to the time the external function within the <code>uDPReceive</code> block was called. This indeterminism may also show up in the plots.
</p>
</html>"), 
    experiment(StartTime = 0, StopTime = 25, Interval = 0.01, Algorithm = "Dassl", Tolerance = 0.0001, DoublePrecision = true, StoreEventValue = false));
end UDPrec;