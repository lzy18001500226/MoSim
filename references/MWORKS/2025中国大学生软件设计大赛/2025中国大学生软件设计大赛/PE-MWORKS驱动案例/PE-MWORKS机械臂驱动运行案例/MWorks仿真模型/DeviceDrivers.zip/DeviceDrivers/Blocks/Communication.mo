within DeviceDrivers.Blocks;
package Communication
  extends Modelica.Icons.Package;
  block UDPReceive "���ڽ��� UDP ���ݱ��Ŀ�"
    extends DeviceDrivers.Utilities.Icons.BaseIcon;
    extends DeviceDrivers.Utilities.Icons.UDPconnection;
    extends DeviceDrivers.Blocks.Communication.Internal.PartialSampleTrigger;

    import DeviceDrivers.Packaging.SerialPackager;
    import DeviceDrivers.Packaging.alignAtByteBoundary;
    import DeviceDrivers.Communication.UDPSocket;
    parameter Boolean autoBufferSize = true
      "true, buffer size is deduced automatically, otherwise set it manually" 
      annotation (Dialog(group = "Incoming data"), choices(checkBox = true));
    parameter Integer userBufferSize = 16 * 1024
      "Buffer size of message data in bytes (if not deduced automatically)" annotation (Dialog(enable = not autoBufferSize, group = "Incoming data"));
    parameter Integer port_recv = 10001
      "Listening port number of the server. Must be unique on the system" 
      annotation (Dialog(group = "Incoming data"));
    Interfaces.PackageOut pkgOut(dummy(start = 0, fixed = true))
      annotation (Placement(transformation(
        extent = {{-20, -20}, {20, 20}}, 
        rotation = 90, 
        origin = {108, 0})));
  protected 
    Integer bufferSize;
    UDPSocket.UDPSocketType socket;
  equation 
    when initial() then 
      pkgOut.pkg = DeviceDrivers.Packaging.SerialPackager.SerialPackager_constructor(if autoBufferSize then bufferSize else userBufferSize);
      socket = DeviceDrivers.Communication.UDPSocket.constructor(port_recv, if autoBufferSize then bufferSize else userBufferSize);
      bufferSize = if autoBufferSize then alignAtByteBoundary(pkgOut.autoPkgBitSize) else userBufferSize;
    end when;
    pkgOut.trigger = actTrigger "using inherited trigger";
    when pkgOut.trigger then 
      pkgOut.dummy = DeviceDrivers.Blocks.Communication.Internal.DummyFunctions.readUDP(
        socket, 
        pkgOut.pkg, 
        time);
    end when;
    when terminal() then 
      DeviceDrivers.Packaging.SerialPackager.SerialPackager_destructor(pkgOut.pkg);
      DeviceDrivers.Communication.UDPSocket.destructor(socket);
    end when;
    annotation (preferredView = "info", 
      Icon(coordinateSystem(preserveAspectRatio = false, extent = {{-100, 
        -100}, {100, 100}}), graphics = {Text(extent = {{-150, 136}, {150, 96}}, 
        textString = "%name")}), Documentation(info = "<html>
<p>Supports receiving of User Datagram Protocol (UDP) datagrams.</p>
</html>"));
  end UDPReceive;
  block UDPSend "���ڷ��� UDP ���ݱ��Ŀ�"
    import DeviceDrivers;
    extends DeviceDrivers.Utilities.Icons.BaseIcon;
    extends DeviceDrivers.Utilities.Icons.UDPconnection;
    extends DeviceDrivers.Blocks.Communication.Internal.PartialSampleTrigger;

    import DeviceDrivers.Packaging.SerialPackager;
    import DeviceDrivers.Communication.UDPSocket;

    parameter Boolean autoBufferSize = true
      "true, buffer size is deduced automatically, otherwise set it manually." 
      annotation (Dialog(group = "Outgoing data"), choices(checkBox = true));
    parameter Integer userBufferSize = 16 * 1024
      "Buffer size of message data in bytes (if not deduced automatically)." annotation (Dialog(enable = not autoBufferSize, group = "Outgoing data"));
    parameter String IPAddress = "127.0.0.1" "IP address of remote UDP server" 
      annotation (Dialog(group = "Outgoing data"));
    parameter Integer port_send = 10002 "Target port of the receiving UDP server" 
      annotation (Dialog(group = "Outgoing data"));
    Interfaces.PackageIn pkgIn annotation (Placement(transformation(
      extent = {{-20, -20}, {20, 20}}, 
      rotation = 270, 
      origin = {-108, 0})));
  protected 
    UDPSocket.UDPSocketType socket;
    Integer bufferSize;
    Real dummy(start = 0, fixed = true);
  equation 
    when initial() then 
      socket = DeviceDrivers.Communication.UDPSocket.constructor(0, 0);
      pkgIn.userPkgBitSize = if autoBufferSize then -1 else userBufferSize * 8;
      pkgIn.autoPkgBitSize = 0;
      bufferSize = if autoBufferSize then DeviceDrivers.Packaging.SerialPackager_.getBufferSize(pkgIn.pkg) else userBufferSize;
    end when;
    when terminal() then 
      DeviceDrivers.Communication.UDPSocket.destructor(socket);
    end when;
    pkgIn.backwardTrigger = actTrigger "using inherited trigger";
    when pkgIn.trigger then 
      dummy = DeviceDrivers.Blocks.Communication.Internal.DummyFunctions.sendToUDP(
        socket, 
        IPAddress, 
        port_send, 
        pkgIn.pkg, 
        bufferSize, 
        pkgIn.dummy);
      Modelica.Utilities.Streams.print("Time=" + String(time));
    end when;
    annotation (preferredView = "info", 
      Icon(coordinateSystem(preserveAspectRatio = true, extent = {{-100, 
        -100}, {100, 100}}), graphics = {Text(extent = {{-150, 136}, {150, 96}}, 
        textString = "%name")}), Documentation(info = "<html>
<p>Supports sending of User Datagram Protocol (UDP) datagrams.</p>
</html>"));
  end UDPSend;
  block TCPIP_Client_IO "���� TCP/IP �׽���ͨ�ŵĿͻ��˿�"
    import DeviceDrivers;
    extends DeviceDrivers.Utilities.Icons.BaseIcon;
    extends DeviceDrivers.Utilities.Icons.TCPIPconnection;
    extends DeviceDrivers.Blocks.Communication.Internal.PartialSampleTrigger;

    import DeviceDrivers.Packaging.SerialPackager;
    import DeviceDrivers.Communication.TCPIPSocketClient;

    parameter String IPAddress = "127.0.0.1" "IP address of remote TCP/IP server";
    parameter Integer port = 10002 "Port of the TCP/IP server";
    parameter Integer outputBufferSize = 16 * 1024
      "Buffer size of message data in bytes." annotation (Dialog(group = "Outgoing data"));
    parameter Integer inputBufferSize = 16 * 1024
      "Buffer size of message data in bytes." annotation (Dialog(group = "Incoming data"));
    Interfaces.PackageIn pkgIn annotation (Placement(transformation(
      extent = {{-20, -20}, {20, 20}}, 
      rotation = 270, 
      origin = {-108, 0})));
    Interfaces.PackageOut pkgOut(dummy(start = 0, fixed = true))
      annotation (Placement(transformation(
        extent = {{-20, -20}, {20, 20}}, 
        rotation = 90, 
        origin = {108, 0})));
  protected 
    TCPIPSocketClient socket = TCPIPSocketClient();
    Boolean isConnected(start = false, fixed = true);
  equation 
    when initial() then 
      pkgOut.pkg = SerialPackager.SerialPackager_constructor(inputBufferSize);
      pkgIn.userPkgBitSize = outputBufferSize * 8;
      pkgIn.autoPkgBitSize = 0;
      isConnected = DeviceDrivers.Communication.TCPIPSocketClient_.connect_(socket, IPAddress, port);
    end when;
    when terminal() then 
      SerialPackager.SerialPackager_destructor(pkgOut.pkg);
    end when;
    pkgIn.backwardTrigger = actTrigger "using inherited trigger";
    pkgOut.trigger = pkgIn.backwardTrigger;
    when pkgIn.backwardTrigger then 
      if isConnected then 
        pkgOut.dummy = DeviceDrivers.Blocks.Communication.Internal.DummyFunctions.readTCPIPServer(
          socket, 
          pkgOut.pkg, 
          inputBufferSize, 
          DeviceDrivers.Blocks.Communication.Internal.DummyFunctions.sendToTCPIPServer(
          socket, 
          pkgIn.pkg, 
          outputBufferSize, 
          pkgIn.dummy));
      else
        pkgOut.dummy = pkgIn.dummy;
      end if;
    end when;
    annotation (preferredView = "info", 
      Icon(coordinateSystem(preserveAspectRatio = true, extent = {{-100, 
        -100}, {100, 100}}), graphics = {Text(extent = {{-150, 136}, {150, 96}}, 
        textString = "%name")}), Documentation(info = "<html>
<p>Supports sending/receiving of packets to/from a server over TCP/IP.</p>
</html>"));
  end TCPIP_Client_IO;
  package Internal
    extends Modelica.Icons.InternalPackage;
    package DummyFunctions
      extends Modelica.Icons.InternalPackage;
      function readUDP
        input DeviceDrivers.Communication.UDPSocket.UDPSocketType socket;
        input DeviceDrivers.Packaging.SerialPackager.SerialPackager pkg;
        input Real dummy;
        output Real dummy2;
      algorithm 
        DeviceDrivers.Communication.UDPSocket_.read(socket, pkg);
        dummy2 := dummy;
      end readUDP;

      function sendToUDP
        input DeviceDrivers.Communication.UDPSocket.UDPSocketType socket;
        input String ipAddress "IP address where data has to be sent";
        input Integer port "Port number where data has to be sent";
        input DeviceDrivers.Packaging.SerialPackager.SerialPackager pkg;
        input Integer dataSize "Size of data";
        input Real dummy;
        output Real dummy2;
      algorithm 
        DeviceDrivers.Communication.UDPSocket_.sendTo(socket, ipAddress, port, pkg, dataSize);
        dummy2 := dummy;
      end sendToUDP;
      function readTCPIPServer
        input DeviceDrivers.Communication.TCPIPSocketClient socket;
        input DeviceDrivers.Packaging.SerialPackager.SerialPackager pkg;
        input Integer dataSize "Size of data";
        input Real dummy;
        output Real dummy2;
      algorithm 
        DeviceDrivers.Communication.TCPIPSocketClient_.read(socket, pkg, dataSize);
        dummy2 := dummy;
      end readTCPIPServer;

      function sendToTCPIPServer
        input DeviceDrivers.Communication.TCPIPSocketClient socket;
        input DeviceDrivers.Packaging.SerialPackager.SerialPackager pkg;
        input Integer dataSize "Size of data";
        input Real dummy;
        output Real dummy2;
      algorithm 
        DeviceDrivers.Communication.TCPIPSocketClient_.sendTo(socket, pkg, dataSize);
        dummy2 := dummy;
      end sendToTCPIPServer;
    end DummyFunctions;

    block PartialSampleTrigger
      "Common code for triggering calls to external I/O devices"
      import SI = Modelica.SIunits;
      parameter Boolean enableExternalTrigger = false
        "true, enable external trigger input signal, otherwise use sample time settings below" 
        annotation (Dialog(group = "Activation"), choices(checkBox = true));
      parameter SI.Period sampleTime = 0.1 "Sample period of component" 
        annotation (Dialog(enable = not enableExternalTrigger, group = "Activation"));
      parameter SI.Time startTime = 0 "First sample time instant" 
        annotation (Dialog(enable = not enableExternalTrigger, group = "Activation"));
      Modelica.Blocks.Interfaces.BooleanInput trigger if enableExternalTrigger
        annotation (Placement(transformation(
          extent = {{-20, -20}, {20, 20}}, 
          rotation = 90, 
          origin = {0, -120})));
    protected 
      Modelica.Blocks.Interfaces.BooleanInput internalTrigger;
      Modelica.Blocks.Interfaces.BooleanInput conditionalInternalTrigger if not enableExternalTrigger;
      Modelica.Blocks.Interfaces.BooleanInput actTrigger annotation (HideResult = true);
    equation 
      /* Condional connect equations to either use external trigger or internal trigger */
      internalTrigger = sample(startTime, sampleTime);
      connect(internalTrigger, conditionalInternalTrigger);
      connect(conditionalInternalTrigger, actTrigger);
      connect(trigger, actTrigger);
      /* "actTrigger" can now be used by extending classes to trigger calls to I/O devices */
    end PartialSampleTrigger;
  end Internal;
end Communication;