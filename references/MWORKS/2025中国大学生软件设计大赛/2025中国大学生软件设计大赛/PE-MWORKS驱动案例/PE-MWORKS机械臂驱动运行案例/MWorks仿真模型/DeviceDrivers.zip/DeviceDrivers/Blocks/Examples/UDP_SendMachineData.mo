﻿within DeviceDrivers.Blocks.Examples;
model UDP_SendMachineData "UDP-发送电机数据"
  extends Modelica.Icons.Example;
  MachineDataSource machineDataSource
    annotation (Placement(transformation(origin = {-40.0, 0.0}, 
      extent = {{-20.0, -20.0}, {20.0, 20.0}})));
  Componment.PeComponment.PETypeEncodeAndSend pETypeEncodeAndSend(localAddress = "192.168.88.172", remoteAddress = "192.168.89.44")
    annotation (Placement(transformation(origin = {40.0, 0.0}, 
      extent = {{-19.999999999999993, -20.0}, {20.0, 20.0}})));
  annotation (experiment(Algorithm = Dassl, Interval = 0.002, StartTime = 0, StopTime = 300, Tolerance = 0.0001));
equation 
  connect(machineDataSource.dataBus, pETypeEncodeAndSend.dataBus)
    annotation (Line(origin = {0.0, 0.0}, 
      points = {{-20.0, 0.0}, {20.0, 0.0}}, 
      color = {255, 215, 136}, 
      thickness = 0.5));
end UDP_SendMachineData;