﻿within DeviceDrivers.Blocks.Examples;
model UDP_SendAndReceiveAAA "UDP同时收发数据"
  annotation (Diagram(coordinateSystem(extent = {{-140.0, -100.0}, {140.0, 100.0}}, 
    preserveAspectRatio = false, 
    grid = {2.0, 2.0})), 
    Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
      preserveAspectRatio = false, 
      grid = {2.0, 2.0})), 
    experiment(Algorithm = Dassl, StartTime = 0, StopTime = 500, Tolerance = 0.0001, Interval = 0.01));
  extends Modelica.Icons.Example;
  //Real x[20];
  Blocks.Communication.UDPReceive uDPReceive(
    autoBufferSize = false, 
    userBufferSize = 200, 
    port_recv = 20001, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {-174.00000000000003, 18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));

  Blocks.Packaging.SerialPackager.GetReal getReal(
    nu = 0, 
    n = 1) annotation (Placement(transformation(origin = {-174.00000000000003, -12.000000000000007}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Blocks.Packaging.SerialPackager.Packager packager(useBackwardPropagatedBufferSize = false, userBufferSize = 36) annotation (Placement(transformation(origin = {-52.000000000000014, 46.0}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Blocks.Packaging.SerialPackager.AddReal addReal(
    nu = 1, 
    n = 1) annotation (Placement(transformation(origin = {-52.000000000000014, 18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));


  Blocks.Communication.UDPSend uDPSend(
    autoBufferSize = false, 
    userBufferSize = 36, 
    port_send = 20002, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {-52.000000000000014, -18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));
  Packaging.SerialPackager.Packager packager1(useBackwardPropagatedBufferSize = false, userBufferSize = 36) annotation (Placement(transformation(origin = {62.000000000000014, 46.0}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Packaging.SerialPackager.AddReal addReal1(
    nu = 1, 
    n = 1) annotation (Placement(transformation(origin = {62.000000000000014, 14.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Communication.UDPSend uDPSend1(
    autoBufferSize = false, 
    userBufferSize = 36, 
    port_send = 20003, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {62.000000000000014, -17.999999999999996}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));
  Modelica.Blocks.Sources.RealExpression realExpression(y = 5 * sin(time))
    annotation (Placement(transformation(origin = {-96.0, 18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression realExpression1(y = 3 * cos(0.15 * time) + time * 0.1)
    annotation (Placement(transformation(origin = {5.000000000000028, 13.999999999999996}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
equation 
  // for i in 1:20 loop 
  //   when getReal.y[i] > 0 then 
  //     x[i] = getReal.y[i];
  //   end when;
  // end for;
  connect(realExpression.y, addReal.u[1])
    annotation (Line(origin = {-83.0, 18.0}, 
      points = {{-2.0, 0.0}, {19.0, 0.0}}, 
      color = {0, 0, 127}));
  connect(addReal.pkgOut[1], uDPSend.pkgIn)
    annotation (Line(origin = {-52.0, 0.0}, 
      points = {{0.0, 7.0}, {0.0, -7.0}}, 
      color = {0, 0, 0}));
  connect(realExpression1.y, addReal1.u[1])
    annotation (Line(origin = {33.0, 14.0}, 
      points = {{-17.0, 0.0}, {17.0, 0.0}}, 
      color = {0, 0, 127}));
  connect(addReal1.pkgOut[1], uDPSend1.pkgIn)
    annotation (Line(origin = {62.0, -2.0}, 
      points = {{0.0, 5.0}, {0.0, -5.0}}, 
      color = {0, 0, 0}));
  connect(packager.pkgOut, addReal.pkgIn)
    annotation (Line(origin = {-52.0, 32.0}, 
      points = {{0.0, 3.0}, {0.0, -3.0}}, 
      color = {0, 0, 0}));
  connect(packager1.pkgOut, addReal1.pkgIn)
    annotation (Line(origin = {62.0, 30.0}, 
      points = {{0.0, 5.0}, {0.0, -5.0}}, 
      color = {0, 0, 0}));
  connect(uDPReceive.pkgOut, getReal.pkgIn)
    annotation (Line(origin = {-174.0, 3.0}, 
      points = {{0.0, 4.0}, {0.0, -4.0}}, 
      color = {0, 0, 0}));
end UDP_SendAndReceiveAAA;