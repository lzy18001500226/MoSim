﻿within DeviceDrivers.Blocks.Examples;
model XNPG_Example "效能评估测例"
  extends Modelica.Icons.Example;
  //
  /***************目标参数配置***************/
  parameter Boolean enable_Target1 = true "场景中是否存在目标一" 
    annotation (choices(checkBox = true), Dialog(tab = "目标配置", group = "目标1", enable = false));
  parameter Integer num_Target1 = 4 "场景中目标一数量" 
    annotation (Dialog(tab = "目标配置", group = "目标1", enable = enable_Target1));

  parameter Boolean enable_Target2 = true "场景中是否需要目标二" 
    annotation (choices(checkBox = true), Dialog(tab = "目标配置", group = "目标2", enable = false));
  parameter Integer num_Target2 = 4 "场景中目标二数量" 
    annotation (Dialog(tab = "目标配置", group = "目标2", enable = enable_Target2));

  parameter Boolean enable_Target3 = true "场景中是否需要目标三" 
    annotation (choices(checkBox = true), Dialog(tab = "目标配置", group = "目标3", enable = false));
  parameter Integer num_Target3 = 5 "场景中目标三数量" 
    annotation (Dialog(tab = "目标配置", group = "目标3", enable = enable_Target3));

  parameter Boolean enable_Target4 = true "场景中是否需要目标四" 
    annotation (choices(checkBox = true), Dialog(tab = "目标配置", group = "目标4", enable = false));
  parameter Integer num_Target4 = 5 "场景中目标四数量" 
    annotation (Dialog(tab = "目标配置", group = "目标4", enable = enable_Target4));

  Componment.PeComponment.PETypeEncodeAndSend pETypeEncodeAndSend(num_Target1 = num_Target1, num_Target2 = num_Target2, num_Target3 = num_Target3, num_Target4 = num_Target4)
    annotation (Placement(transformation(origin = {50.0, 10.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  // Componment.PeComponment.Target Target1[num_Target1]
  //   annotation (Placement(transformation(origin = {-50.0, 70.0}, 
  //     extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.CombiTimeTable Target1(tableOnFile = true, 
    tableName = "tab1", 
    columns = 2:(1 + 7 * num_Target1), 
    fileName = Modelica.Utilities.Files.loadResource("modelica://DeviceDrivers/Resources/data/Target1_data.txt")) if enable_Target1
    annotation (Placement(transformation(origin = {-50.0, 69.99999999999999}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.CombiTimeTable Target2(tableOnFile = true, 
    tableName = "tab2", 
    columns = 2:(1 + 7 * num_Target2), 
    fileName = Modelica.Utilities.Files.loadResource("modelica://DeviceDrivers/Resources/data/Target2_data.txt")) if enable_Target2
    annotation (Placement(transformation(origin = {-50.0, 30.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.CombiTimeTable Target3(tableOnFile = true, 
    tableName = "tab3", 
    columns = 2:(1 + 7 * num_Target3), 
    fileName = Modelica.Utilities.Files.loadResource("modelica://DeviceDrivers/Resources/data/Target3_data.txt")) if enable_Target3
    annotation (Placement(transformation(origin = {-50.0, -9.999999999999993}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.CombiTimeTable Target4(tableOnFile = true, 
    tableName = "tab4", 
    columns = 2:(1 + 7 * num_Target4), 
    fileName = Modelica.Utilities.Files.loadResource("modelica://DeviceDrivers/Resources/data/Target4_data.txt")) if enable_Target4
    annotation (Placement(transformation(origin = {-50.0, -50.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
equation 
  //
  //
  //指定变量赋值给通信组件接口
  //目标1
  pETypeEncodeAndSend.dataBus.num1 = num_Target1;

  for i in 1:num_Target1 loop 
    pETypeEncodeAndSend.dataBus.X1[i] = if enable_Target1 then Target1.y[i] else -1;
    pETypeEncodeAndSend.dataBus.Y1[i] = if enable_Target1 then Target1.y[i + num_Target1 * 1] else -1;
    pETypeEncodeAndSend.dataBus.Z1[i] = if enable_Target1 then Target1.y[i + num_Target1 * 2] else -1;
    pETypeEncodeAndSend.dataBus.thetaX1[i] = if enable_Target1 then Target1.y[i + num_Target1 * 3] else -1;
    pETypeEncodeAndSend.dataBus.thetaY1[i] = if enable_Target1 then Target1.y[i + num_Target1 * 4] else -1;
    pETypeEncodeAndSend.dataBus.thetaZ1[i] = if enable_Target1 then Target1.y[i + num_Target1 * 5] else -1;
    pETypeEncodeAndSend.dataBus.IfDestroyed1[i] = if enable_Target1 then Target1.y[i + num_Target1 * 6] else -1;
  end for;
    //目标2
  pETypeEncodeAndSend.dataBus.num2 = num_Target2;
  for i in 1:num_Target2 loop 
    pETypeEncodeAndSend.dataBus.X2[i] = if enable_Target2 then Target2.y[i] else -1;
    pETypeEncodeAndSend.dataBus.Y2[i] = if enable_Target2 then Target2.y[i + num_Target2 * 1] else -1;
    pETypeEncodeAndSend.dataBus.Z2[i] = if enable_Target2 then Target2.y[i + num_Target2 * 2] else -1;
    pETypeEncodeAndSend.dataBus.thetaX2[i] = if enable_Target2 then Target2.y[i + num_Target2 * 3] else -1;
    pETypeEncodeAndSend.dataBus.thetaY2[i] = if enable_Target2 then Target2.y[i + num_Target2 * 4] else -1;
    pETypeEncodeAndSend.dataBus.thetaZ2[i] = if enable_Target2 then Target2.y[i + num_Target2 * 5] else -1;
    pETypeEncodeAndSend.dataBus.IfDestroyed2[i] = if enable_Target2 then Target2.y[i + num_Target2 * 6] else -1;
  end for;
    //目标3
  pETypeEncodeAndSend.dataBus.num3 = num_Target3;
  for i in 1:num_Target3 loop 
    pETypeEncodeAndSend.dataBus.X3[i] = if enable_Target3 then Target3.y[i] else -1;
    pETypeEncodeAndSend.dataBus.Y3[i] = if enable_Target3 then Target3.y[i + num_Target3 * 1] else -1;
    pETypeEncodeAndSend.dataBus.Z3[i] = if enable_Target3 then Target3.y[i + num_Target3 * 2] else -1;
    pETypeEncodeAndSend.dataBus.thetaX3[i] = if enable_Target3 then Target3.y[i + num_Target3 * 3] else -1;
    pETypeEncodeAndSend.dataBus.thetaY3[i] = if enable_Target3 then Target3.y[i + num_Target3 * 4] else -1;
    pETypeEncodeAndSend.dataBus.thetaZ3[i] = if enable_Target3 then Target3.y[i + num_Target3 * 5] else -1;
    pETypeEncodeAndSend.dataBus.IfDestroyed3[i] = if enable_Target3 then Target3.y[i + num_Target3 * 6] else -1;
  end for;
    //目标4
  pETypeEncodeAndSend.dataBus.num4 = num_Target4;
  for i in 1:num_Target4 loop 
    pETypeEncodeAndSend.dataBus.X4[i] = if enable_Target4 then Target4.y[i] else -1;
    pETypeEncodeAndSend.dataBus.Y4[i] = if enable_Target4 then Target4.y[i + num_Target4 * 1] else -1;
    pETypeEncodeAndSend.dataBus.Z4[i] = if enable_Target4 then Target4.y[i + num_Target4 * 2] else -1;
    pETypeEncodeAndSend.dataBus.thetaX4[i] = if enable_Target4 then Target4.y[i + num_Target4 * 3] else -1;
    pETypeEncodeAndSend.dataBus.thetaY4[i] = if enable_Target4 then Target4.y[i + num_Target4 * 4] else -1;
    pETypeEncodeAndSend.dataBus.thetaZ4[i] = if enable_Target4 then Target4.y[i + num_Target4 * 5] else -1;
    pETypeEncodeAndSend.dataBus.IfDestroyed4[i] = if enable_Target4 then Target4.y[i + num_Target4 * 6] else -1;
  end for;
end XNPG_Example;