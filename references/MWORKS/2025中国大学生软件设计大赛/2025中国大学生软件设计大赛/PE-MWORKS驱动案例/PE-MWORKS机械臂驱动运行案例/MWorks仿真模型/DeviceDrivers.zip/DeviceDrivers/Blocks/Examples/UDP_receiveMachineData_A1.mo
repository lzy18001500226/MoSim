﻿within DeviceDrivers.Blocks.Examples;
model UDP_receiveMachineData_A1
  "UDP接收电机数据"
  extends Modelica.Icons.Example;
  Communication.UDPReceive uDPReceive(
    autoBufferSize = false, 
    userBufferSize = 36, 
    port_recv = 10002, 
    sampleTime = 0.1, startTime = 0)


    annotation (Placement(transformation(
      origin = {40, 50}, 
      extent = {{-10, -10}, {10, 10}}, 
      rotation = 270)));
  Packaging.SerialPackager.GetReal getReal(
    nu = 1, 
    n = 3) annotation (Placement(transformation(extent = {{30, 10}, {50, 30}})));
  Packaging.SerialPackager.GetInteger getInteger(nu = 0, n = 1) annotation (Placement(transformation(origin = {40.0, -18.0}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
equation 
  annotation (
    Documentation(info = "<html>
<p>
The <code>uDPSend</code> block sends to the local port 10002. The <code>uDPReceive</code> block starts a background process that listens at port 10002. Consequently, the <code>uDPReceive</code> block receives what the <code>uDPSend</code> block sends.
</p>
<p>
<b>Note:</b> There is no causality between the <code>uDPSend</code> block and the <code>uDPReceive</code> block. Therefore the execution order of the blocks is not determined. Additionally, the <code>uDPReceive</code> block starts an own receiving thread, so that the time the data was received is not equal to the time the external function within the <code>uDPReceive</code> block was called. This indeterminism may also show up in the plots.
</p>
</html>"), 
    experiment(StartTime = 0, StopTime = 150, Interval = 0.1, Algorithm = Dassl, Tolerance = 0.0001, DoublePrecision = true, StoreEventValue = false));
  connect(uDPReceive.pkgOut, getReal.pkgIn)
    annotation (Line(origin = {40.0, 35.0}, 
      points = {{0.0, 4.0}, {0.0, -4.0}}));
  connect(getReal.pkgOut[1], getInteger.pkgIn)
    annotation (Line(origin = {40.0, 1.0}, 
      points = {{0.0, 8.0}, {0.0, -8.0}}, 
      color = {0, 0, 0}));
end UDP_receiveMachineData_A1;