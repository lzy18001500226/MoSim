within DeviceDrivers.Blocks;
package Packaging
  extends Modelica.Icons.Package;
end Packaging;