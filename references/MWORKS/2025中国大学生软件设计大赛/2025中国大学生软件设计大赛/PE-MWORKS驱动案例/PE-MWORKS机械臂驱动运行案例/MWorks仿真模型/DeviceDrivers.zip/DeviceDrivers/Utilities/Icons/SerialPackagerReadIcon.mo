within DeviceDrivers.Utilities.Icons;
partial block SerialPackagerReadIcon

  annotation (Icon(coordinateSystem(preserveAspectRatio = true, extent = {{-100, 
    -100}, {100, 100}}), graphics = {Text(
    extent = {{-100, 96}, {100, 56}}, 
    textString = "%name"), Bitmap(extent = {{-94, -40}, {-14, 40}}, 
    fileName = "modelica://DeviceDrivers/Resources/Images/Icons/package.png")}));
end SerialPackagerReadIcon;