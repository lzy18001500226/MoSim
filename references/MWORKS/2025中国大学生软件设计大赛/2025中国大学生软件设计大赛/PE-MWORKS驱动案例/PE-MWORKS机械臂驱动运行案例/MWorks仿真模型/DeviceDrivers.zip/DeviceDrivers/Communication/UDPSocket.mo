within DeviceDrivers.Communication;
package UDPSocket "A driver for UDP packet network communication."
  //extends ExternalObject;
  type UDPSocketType = Integer[2];

  function constructor
    "Creates a UDPSocket instance with a given listening port."
    import Modelica;
    extends Modelica.Icons.Function;
    import DeviceDrivers.Communication.UDPSocket;
    input Integer port "0 if a sending socket, otherwise the number of the listening port";
    input Integer bufferSize = 16 * 1024 "Size of receive buffer, can be safely set to 0 for a sending socket";
    output UDPSocketType socket;
  external "C" MDD_udpConstructor(socket, port, bufferSize)
  annotation (Include = "#include \"MDDUDPSocket.h\"", LibraryDirectory = "modelica://DeviceDrivers/Resources/Library", 
    __iti_dll = "ITI_MDD.dll", 
    __iti_dllNoExport = true);
  end constructor;

  function destructor
    import Modelica;
    extends Modelica.Icons.Function;
    import DeviceDrivers.Communication.UDPSocket;
    input UDPSocketType socket;
  external "C" MDD_udpDestructor(socket)
  annotation (Include = "#include \"MDDUDPSocket.h\"", 
    __iti_dll = "ITI_MDD.dll", 
    __iti_dllNoExport = true);
  end destructor;

end UDPSocket;