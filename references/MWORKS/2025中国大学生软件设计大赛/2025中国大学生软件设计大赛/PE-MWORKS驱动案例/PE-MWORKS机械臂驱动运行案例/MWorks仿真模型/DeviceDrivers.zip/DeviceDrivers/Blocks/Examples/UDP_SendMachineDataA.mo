﻿within DeviceDrivers.Blocks.Examples;
model UDP_SendMachineDataA "UDP-发送电机数据"
  extends Modelica.Icons.Example;



  Componment.PeComponment.PETypeEncodeAndSendA pETypeEncodeAndSend(localAddress = "127.0.0.1", remoteAddress = "127.0.0.1") annotation (Placement(transformation(origin = {40.0, 0.0}, 
    extent = {{-19.999999999999993, -20.0}, {20.0, 20.0}})));

  annotation (experiment(Algorithm = Dassl, Interval = 0.001, StartTime = 0, StopTime = 150, Tolerance = 0.0001));
equation 
end UDP_SendMachineDataA;