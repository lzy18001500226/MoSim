﻿within DeviceDrivers.Blocks.Examples;
model MachineDataSource "电机数据信号源"
  annotation (Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
    grid = {2.0, 2.0}), graphics = {Rectangle(origin = {0.0, 0.0}, 
    fillColor = {246, 255, 230}, 
    fillPattern = FillPattern.Solid, 
    lineThickness = 0.5, 
    extent = {{-100.0, 100.0}, {100.0, -100.0}}, 
    radius = 10.0), Text(origin = {-3.0, -2.0}, 
    lineColor = {0, 0, 0}, 
    extent = {{-77.0, 28.0}, {77.0, -28.0}}, 
    textString = "电机数据信号源", 
    textStyle = {TextStyle.None}, 
    textColor = {0, 0, 0}, 
    horizontalAlignment = LinePattern.None)}));
  Componment.PeComponment.DataBus dataBus
    annotation (Placement(transformation(origin = {100.0, 0.0}, 
      extent = {{-20.0, -20.0}, {20.0, 20.0}}, 
      rotation = -90.0)));
equation 
  dataBus.Time = time;
  dataBus.T_a1 = 50 + 10 * sin(time * 0.2);
  dataBus.T_a2 = 30 + 5 * sin(time * 0.1 + 2);
  dataBus.T_a3 = 80 - 10 * sin(time * 0.5 + 6);
end MachineDataSource;