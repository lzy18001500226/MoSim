﻿within DeviceDrivers.Blocks.Examples;
model UDP_SendAndReceiveCC "UDP接收数据-双通道"
  annotation (Diagram(coordinateSystem(extent = {{-140.0, -100.0}, {140.0, 100.0}}, 
    preserveAspectRatio = false, 
    grid = {2.0, 2.0})), 
    Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
      preserveAspectRatio = false, 
      grid = {2.0, 2.0})), 
    experiment(Algorithm = Dassl, StartTime = 0, StopTime = 500, Tolerance = 0.0001, Interval = 0.01));
  extends Modelica.Icons.Example;
  Real x[20];
  Blocks.Communication.UDPReceive uDPReceive(
    autoBufferSize = false, 
    userBufferSize = 200, 
    port_recv = 20002, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {1.999999999999993, 18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));

  Blocks.Packaging.SerialPackager.GetReal getReal(
    nu = 0, 
    n = 4) annotation (Placement(transformation(origin = {1.999999999999993, -12.000000000000007}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Communication.UDPReceive uDPReceive1(
    autoBufferSize = false, 
    userBufferSize = 10, 
    port_recv = 6691, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {56.00000000000001, 18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));
  Packaging.SerialPackager.GetReal getReal1(
    nu = 0, 
    n = 1) annotation (Placement(transformation(origin = {56.00000000000001, -12.000000000000007}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
equation 
  for i in 1:20 loop 
    when getReal.y[i] > 0 then 
      x[i] = getReal.y[i];
    end when;
  end for;
  connect(uDPReceive.pkgOut, getReal.pkgIn)
    annotation (Line(origin = {2.0, 3.0}, 
      points = {{0.0, 4.0}, {0.0, -4.0}}));
  connect(uDPReceive1.pkgOut, getReal1.pkgIn)
    annotation (Line(origin = {56.0, 3.0}, 
      points = {{0.0, 4.0}, {0.0, -4.0}}, 
      color = {0, 0, 0}));
end UDP_SendAndReceiveCC;