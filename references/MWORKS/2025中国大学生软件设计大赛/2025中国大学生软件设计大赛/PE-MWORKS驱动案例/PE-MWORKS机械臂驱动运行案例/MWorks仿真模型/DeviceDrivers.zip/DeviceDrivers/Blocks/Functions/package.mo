﻿within DeviceDrivers.Blocks;
package Functions "函数功能"
  extends DeviceDrivers.Utilities.Icons.FunctionLayerIcon;
  function SendData
    input Componment.Socket socketObj;
    input Componment.NameValue valObj;
    input String remoteAddress;
    input Integer remotePort;
    output Integer isSendOk;
  external "C" isSendOk = SendData(socketObj, valObj, remoteAddress, remotePort)
  annotation (
    Library = "Utilities_NetWork");
  end SendData;


  function UpdateValue
    input Componment.NameValue valObj;
    input String varName;
    input Real val;
  external "C" UpdateValue(valObj, varName, val)
  annotation (
    Library = "Utilities_NetWork");
  end UpdateValue;


  function Update2DTableValue
    input Componment.NameValue obj;
    input String tableName;
    input Real[:,:] tablevals;
    input Integer rowCount;
    input Integer colCount;
  external "C" Update2dTableValue(obj, tableName, tablevals, rowCount, colCount)
  annotation (Library = "Utilities_Network");
  end Update2DTableValue;

  function Update1DTableValue
    input Componment.NameValue obj;
    input String tableName;
    input Real[:] tablevals;
    input Integer colCount;
  external "C" Update1dTableValue(obj, tableName, tablevals, colCount)
  annotation (Library = "Utilities_Network");
  end Update1DTableValue;
  function GetData
    input Componment.NameValue valObj;
    input String varName;
    output Boolean isOk;
    output Real val;


  external "C" isOk = GetValue(valObj, varName, val)
  annotation (
    Library = "Utilities_NetWork");
  end GetData;
  function Get1DTableValue
    input Componment.NameValue valObj;
    input String varName;
    input Real cols;
    output Boolean isOk;
    output Real[cols] val;

  external "C" isOk = Get1dTableValue(valObj, varName, cols, val)
  annotation (
    Library = "Utilities_NetWork");
  end Get1DTableValue;

  function Get2DTableValue
    input Componment.NameValue valObj;
    input String varName;
    input Integer rows;
    input Integer cols;

    output Boolean isOk;
    output Real[rows,cols] val;

  external "C" isOk = Get2dTableValue(valObj, varName, size(val, 1), size(val, 2), val)
  annotation (
    Library = "Utilities_NetWork");
  end Get2DTableValue;
  function RecvData
    input Componment.Socket socketObj;
    input Componment.NameValue valObj;
    input String remoteAddress;
    output Boolean isGetOk;
    //external "C" isGetOk = RecvData(socketObj, valObj, remoteAddress, remotePort)
  external "C" isGetOk = RecvData(socketObj, valObj, remoteAddress)
  annotation (
    Library = "Utilities_NetWork");
  end RecvData;
  function Get2dFlexibleArrayToFile
    input Componment.NameValue valObj;
    input String varName;
    input String filePath;

    output Boolean isOk;

  external "C" isOk = Get2dFlexibleArrayToFile(valObj, varName, filePath)
  annotation (
    Library = "Utilities_NetWork");
  end Get2dFlexibleArrayToFile;


  function Get1dFlexibleArrayToFile
    input Componment.NameValue valObj;
    input String varName;
    input String filePath;

    output Boolean isOk;

  external "C" isOk = Get1dFlexibleArrayToFile(valObj, varName, filePath)
  annotation (
    Library = "Utilities_NetWork");
  end Get1dFlexibleArrayToFile;
  function WaitResponse
    input Componment.Socket socketObj;
    input String responseName;
    input String remoteAddr;
    output Boolean isNoTimeOut;
  external "C" isNoTimeOut = WaitResponse(socketObj, responseName, remoteAddr)
  annotation (
    Library = "Utilities_NetWork");
  end WaitResponse;

  function RequestAndWait
    input String requestName;
    input String responseName;
    input Integer requestVal;
    input Integer remotePort;
    input Integer recvPort;
    input Real cur_time;

    output Integer isSendOk;

  external "C" isSendOk = RequestAndWait(requestName, responseName, requestVal, remotePort, recvPort, cur_time)
  annotation (
    Library = "Utilities_NetWork");
  end RequestAndWait;
  function GetImageAndWait
    input Integer remotePort;
    input Integer recvPort;
    input Real curTime;
    output Integer isOk;
  algorithm 
    isOk := RequestAndWait("getImages", "res_imgSucceed", 1, remotePort, recvPort, curTime);

  end GetImageAndWait;
end Functions;