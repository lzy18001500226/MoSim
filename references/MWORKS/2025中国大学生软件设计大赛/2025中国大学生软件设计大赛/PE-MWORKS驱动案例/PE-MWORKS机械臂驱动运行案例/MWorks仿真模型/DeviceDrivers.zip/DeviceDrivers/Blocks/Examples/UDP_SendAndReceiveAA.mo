﻿within DeviceDrivers.Blocks.Examples;
model UDP_SendAndReceiveAA "UDP同时收发数据"
  annotation (Diagram(coordinateSystem(extent = {{-140.0, -100.0}, {140.0, 100.0}}, 
    preserveAspectRatio = false, 
    grid = {2.0, 2.0})), 
    Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
      preserveAspectRatio = false, 
      grid = {2.0, 2.0})), 
    experiment(Algorithm = Dassl, StartTime = 0, StopTime = 500, Tolerance = 0.0001, Interval = 0.01));
  extends Modelica.Icons.Example;
  Real x[20];
  Blocks.Communication.UDPReceive uDPReceive(
    autoBufferSize = false, 
    userBufferSize = 200, 
    port_recv = 20002, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {1.999999999999993, 18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));

  Blocks.Packaging.SerialPackager.GetReal getReal(
    nu = 0, 
    n = 20) annotation (Placement(transformation(origin = {1.999999999999993, -12.000000000000007}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
equation 
  for i in 1:20 loop 
    when getReal.y[i] > 0 then 
      x[i] = getReal.y[i];
    end when;
  end for;
  connect(uDPReceive.pkgOut, getReal.pkgIn)
    annotation (Line(origin = {2.0, 3.0}, 
      points = {{0.0, 4.0}, {0.0, -4.0}}));
end UDP_SendAndReceiveAA;