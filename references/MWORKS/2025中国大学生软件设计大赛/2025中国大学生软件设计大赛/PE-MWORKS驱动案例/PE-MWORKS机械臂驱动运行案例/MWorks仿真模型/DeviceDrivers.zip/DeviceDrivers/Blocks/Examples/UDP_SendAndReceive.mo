﻿within DeviceDrivers.Blocks.Examples;
model UDP_SendAndReceive "UDP同时收发数据"
  annotation (Diagram(coordinateSystem(extent = {{-140.0, -100.0}, {140.0, 100.0}}, 
    preserveAspectRatio = false, 
    grid = {2.0, 2.0})), 
    Icon(coordinateSystem(extent = {{-100.0, -100.0}, {100.0, 100.0}}, 
      preserveAspectRatio = false, 
      grid = {2.0, 2.0})), 
    experiment(Algorithm = Dassl, StartTime = 0, StopTime = 500, Tolerance = 0.0001, Interval = 0.01));
  extends Modelica.Icons.Example;
  Real x[20];
  Blocks.Communication.UDPReceive uDPReceive(
    autoBufferSize = false, 
    userBufferSize = 200, 
    port_recv = 20002, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {1.999999999999993, 18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));

  Blocks.Packaging.SerialPackager.GetReal getReal(
    nu = 0, 
    n = 20) annotation (Placement(transformation(origin = {1.999999999999993, -12.000000000000007}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Blocks.Packaging.SerialPackager.Packager packager(useBackwardPropagatedBufferSize = false, userBufferSize = 36) annotation (Placement(transformation(origin = {-52.000000000000014, 46.0}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Blocks.Packaging.SerialPackager.AddReal addReal(
    nu = 1, 
    n = 1) annotation (Placement(transformation(origin = {-52.000000000000014, 18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Modelica.Blocks.Sources.RealExpression realExpression[1](y = time) annotation (Placement(transformation(origin = {-92.00000000000001, 18.0}, 
    extent = {{-10.0, -10.0}, {10.0, 10.0}})));
  Blocks.Communication.UDPSend uDPSend(
    autoBufferSize = false, 
    userBufferSize = 36, 
    port_send = 20001, 
    sampleTime = 0.01)


    annotation (Placement(transformation(origin = {-52.000000000000014, -18.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));
equation 
  for i in 1:20 loop 
    when getReal.y[i] > 0 then 
      x[i] = getReal.y[i];
    end when;
  end for;
  connect(uDPReceive.pkgOut, getReal.pkgIn)
    annotation (Line(origin = {2.0, 3.0}, 
      points = {{0.0, 4.0}, {0.0, -4.0}}));
  connect(realExpression.y, addReal.u)
    annotation (Line(origin = {-72.0, 18.0}, 
      points = {{-9.0, 0.0}, {8.0, 0.0}}, 
      color = {0, 0, 127}));
  connect(packager.pkgOut, addReal.pkgIn)
    annotation (Line(origin = {-52.0, 32.0}, 
      points = {{0.0, 3.0}, {0.0, -3.0}}, 
      color = {0, 0, 0}));
  connect(addReal.pkgOut[1], uDPSend.pkgIn)
    annotation (Line(origin = {-52.0, 0.0}, 
      points = {{0.0, 7.0}, {0.0, -7.0}}, 
      color = {0, 0, 0}));
end UDP_SendAndReceive;