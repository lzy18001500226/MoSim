within DeviceDrivers.Blocks;
package Interfaces
  extends Modelica.Icons.InterfacesPackage;

  connector PackageIn "��װ������������"
    input DeviceDrivers.Packaging.SerialPackager.SerialPackager pkg;
    input Boolean trigger;
    input Real dummy;

    output Boolean backwardTrigger;
    output Integer userPkgBitSize;
    output Integer autoPkgBitSize;
    annotation (defaultComponentName = "pkgIn", 
      Icon(coordinateSystem(preserveAspectRatio = true, extent = {{-100, -100}, {100, 100}}, 
        initialScale = 0.2), graphics = {Rectangle(
        extent = {{-100, 40}, {100, -40}}, 
        fillColor = {255, 255, 0}, 
        fillPattern = FillPattern.Sphere), 
        Line(
        points = {{-100, -40}, {0, 40}, {100, -40}}, 
        color = {95, 95, 95}), 
        Line(
        points = {{-52, -40}, {0, 0}, {50, -40}}, 
        color = {95, 95, 95})}));
  end PackageIn;

  connector PackageOut "��װ�����������"
    output DeviceDrivers.Packaging.SerialPackager.SerialPackager pkg;
    output Boolean trigger;
    output Real dummy;

    input Boolean backwardTrigger;
    input Integer userPkgBitSize;
    input Integer autoPkgBitSize;
    annotation (defaultComponentName = "pkgOut", 
      Icon(coordinateSystem(preserveAspectRatio = true, extent = {{-100, -100}, {100, 100}}, 
        initialScale = 0.2), graphics = {Rectangle(
        extent = {{-100, 40}, {100, -40}}, 
        fillColor = {255, 255, 0}, 
        fillPattern = FillPattern.Sphere), 
        Line(
        points = {{-100, 40}, {0, -40}, {100, 40}}, 
        color = {95, 95, 95}), 
        Line(
        points = {{-50, 40}, {2, 0}, {52, 40}}, 
        color = {95, 95, 95})}));
  end PackageOut;
end Interfaces;