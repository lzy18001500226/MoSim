﻿within DeviceDrivers.Blocks.Examples;
model UDP_receiveMachineData
  "UDP接收电机数据"
  extends Modelica.Icons.Example;
  Communication.UDPReceive uDPReceive(
    autoBufferSize = true, 
    userBufferSize = 32, 
    port_recv = 10004, 
    sampleTime = 0.1)


    annotation (Placement(transformation(origin = {-10.0, 50.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}}, 
      rotation = 270.0)));

  Packaging.SerialPackager.GetReal getReal(
    nu = 0, 
    n = 4) annotation (Placement(transformation(origin = {-10.0, 20.0}, 
      extent = {{-10.0, -10.0}, {10.0, 10.0}})));
equation 
  annotation (
    Documentation(info = "<html>
<p>
The <code>uDPSend</code> block sends to the local port 10002. The <code>uDPReceive</code> block starts a background process that listens at port 10002. Consequently, the <code>uDPReceive</code> block receives what the <code>uDPSend</code> block sends.
</p>
<p>
<b>Note:</b> There is no causality between the <code>uDPSend</code> block and the <code>uDPReceive</code> block. Therefore the execution order of the blocks is not determined. Additionally, the <code>uDPReceive</code> block starts an own receiving thread, so that the time the data was received is not equal to the time the external function within the <code>uDPReceive</code> block was called. This indeterminism may also show up in the plots.
</p>
</html>"), 
    experiment(StartTime = 0, StopTime = 150, Interval = 0.1, Algorithm = Dassl, Tolerance = 0.0001, DoublePrecision = true, StoreEventValue = false));
  connect(getReal.pkgIn, uDPReceive.pkgOut)
    annotation (Line(origin = {-10.0, 35.0}, 
      points = {{0.0, -4.0}, {0.0, 4.0}}, 
      color = {0, 0, 0}));
end UDP_receiveMachineData;